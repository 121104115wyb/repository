package com.renogy.device.rdplibrary.device.parse

/**
 * @author Create by 17474 on 2024/11/12.
 * Email： lishuwentimor1994@163.com
 * Describe：单位
 */
object UnitConsts {
    const val AMPS = "A"
    const val VOLTS = "V"
    const val DAY = "day"
    const val MIN = "min"
    const val AH = "Ah"
    const val KWH = "kwh"
    const val HZ = "hz"
}