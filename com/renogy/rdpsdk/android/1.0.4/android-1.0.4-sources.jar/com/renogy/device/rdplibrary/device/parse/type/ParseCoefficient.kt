package com.renogy.device.rdplibrary.device.parse.type

import com.renogy.device.rdplibrary.device.entity.BaseParseEntity
import com.renogy.device.rdplibrary.device.entity.IntParseEntity

/**
 * @author Create by 17474 on 2024/11/12.
 * Email： lishuwentimor1994@163.com
 * Describe：系数解析,系数为1
 */
class ParseCoefficient : BaseParseService (){

    override fun parse(hexResp: String): BaseParseEntity {
        return IntParseEntity(hexResp.toInt(16), hexResp)
    }
}