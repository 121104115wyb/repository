package com.renogy.device.rdplibrary.device.parse.type

import com.renogy.device.rdplibrary.device.entity.BaseParseEntity
import com.renogy.device.rdplibrary.device.entity.BatCellTempParseEntity
import com.renogy.device.rdplibrary.device.entity.IntParseEntity

/**
 * 解析电池温度探针温度
 */
class ParseBatCellTemp : BaseParseService() {
    override fun parse(hexResp: String): BaseParseEntity {
        return BatCellTempParseEntity(hexResp)
    }
}