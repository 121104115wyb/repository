package com.renogy.device.rdplibrary.device.parse.type

import com.renogy.device.rdplibrary.device.entity.BaseParseEntity
import com.renogy.device.rdplibrary.device.entity.BatCellParseEntity

/**
 * 解析电池电芯电压
 */
class ParseBatCellVolts : BaseParseService() {
    override fun parse(hexResp: String): BaseParseEntity {
        return BatCellParseEntity(hexResp)
    }
}