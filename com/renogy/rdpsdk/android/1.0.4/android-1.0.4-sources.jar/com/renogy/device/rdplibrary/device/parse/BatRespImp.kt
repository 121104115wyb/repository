package com.renogy.device.rdplibrary.device.parse

import android.util.Log
import com.renogy.device.rdplibrary.device.bat.BatConsts
import com.renogy.device.rdplibrary.device.entity.BaseParseEntity
import com.renogy.device.rdplibrary.device.entity.ErrorParseEntity
import com.renogy.device.rdplibrary.device.parse.type.ParseBit

/**
 * @author Create by 17474 on 2024/11/12.
 * Email： lishuwentimor1994@163.com
 * Describe：电池解析 developing
 */
class BatRespImp : BaseRespService {

    override fun parse(cmdTag: String, hexResp: String, parseType: String): BaseParseEntity {
        //数据截止位置
        val subEndIndex = ParseConsts.getSubEndIndex(hexResp)
        //待解析的数据
        val parseHexResp = hexResp.substring(6, subEndIndex)
        //解析服务
        val parseService = ParseFactory.getParseImpl(parseType)
        when (cmdTag) {
            BatConsts.HEATER_MODE_STATUS -> {
                Log.d("BatRespImp", "BatConsts.HEATER_MODE_STATUS：$parseHexResp")
                if (parseService is ParseBit) {
                    parseService.start = 13
                    parseService.end = 14
                    parseService.selectList = BatConsts.getBatHeatModeList()
                }
            }
        }
        return parseService?.parse(parseHexResp) ?: ErrorParseEntity(
            "parse error:\ncmdTag:$cmdTag\nhexResp:$hexResp\nparseType:$parseType ",
            ""
        )
    }
}