package com.renogy.device.rdplibrary.device.ctrl

import com.renogy.device.rdplibrary.ProtocolsConsts
import com.renogy.device.rdplibrary.R
import com.renogy.device.rdplibrary.device.anotation.DeviceType
import com.renogy.device.rdplibrary.device.anotation.ParseType
import com.renogy.device.rdplibrary.device.entity.BaseSelectEntity

/**
 * @author Create by 17474 on 2024/11/11.
 * Email： lishuwentimor1994@163.com
 * Describe：Controller
 * 目前只支持读取数据,每个参数的命令标识组成为"deviceType#parameterName#ParseType"
 * 比如控制设备地址的命令tag为"ctrl#device_address#parse_not"
 * 由此可以得知，这是控制的命令,参数的名称为设备地址,解析方式为不解析
 * 后续可能开放更多的控制器指令
 */
object CtrlConsts {
    //device address
    var DEVICE_ADDRESS = getTag("device_address", ParseType.PARSE_NOT)

    //device model
    var SKU = getTag("sku", ParseType.PARSE_ASCII)

    //固件版本
    var FIRMWARE_VERSION = getTag("firmware_version", ParseType.DEV_VERSION)

    //软件版本
    var SOFTWARE_VERSION = getTag("software_version", ParseType.DEV_VERSION)

    //预估SOC
    var ESTIMATED_SOC = getTag("estimated_soc", ParseType.COEFFICIENT)

    //电池充电电压
    var BATTERY_CHARGING_VOLTS = getTag("battery_charging_volts", ParseType.TENTHS_COEFFICIENT)

    //电池充电电流
    var BATTERY_CHARGING_AMPS = getTag("battery_charging_amps", ParseType.THOUSANDTH_COEFFICIENT)

    //控制器内部温度
    var CTRL_TEMP = getTag("ctrl_temp", ParseType.PARSE_2_BITS_HIGHER_TEMP)

    //电池温度
    var BATTERY_TEMP = getTag("battery_temp", ParseType.PARSE_2_BITS_LOW_TEMP)

    //负载电压
    var LOAD_VOLTS = getTag("load_volts", ParseType.TENTHS_COEFFICIENT)

    //负载电流
    var LOAD_AMPS = getTag("load_amps", ParseType.COEFFICIENT)

    //太阳能板电压
    var SOLAR_VOLTS = getTag("solar_volts", ParseType.TENTHS_COEFFICIENT)

    //太阳能板电流
    var SOLAR_AMPS = getTag("solar_amps", ParseType.COEFFICIENT)

    //类记发电量
    var TOTAL_POWER_GENERATION = getTag("total_power_generation", ParseType.THOUSANDTH_COEFFICIENT)

    //充电状态
    var CHARGING_STATUS = getTag("charging_status", ParseType.SELECT_2_BITS_LOWER)

    //电池类型
    var BATTERY_TYPE = getTag("battery_type", ParseType.SELECT)

    //DC负载输出
    var DC_LOAD_OUTPUT = getTag("dc_load_output", ParseType.PARSE_NOT)

    //系统电压
    var SYSTEM_VOLTS = getTag("system_volts", ParseType.SYS_VOLTS)

    //负载状态
    var LOAD_STATUS = getTag("load_status", ParseType.SELECT)

    //升压电压
    var BOOST_VOLTS = getTag("boost_volts", ParseType.TENTHS_COEFFICIENT)

    //浮动电压
    var FLOAT_VOLTS = getTag("float_volts", ParseType.TENTHS_COEFFICIENT)

    //均衡电压
    var EQUALIZATION_VOLTS = getTag("equalization_volts", ParseType.TENTHS_COEFFICIENT)

    //提升持续时间
    var BOOST_DURATION = getTag("boost_duration", ParseType.COEFFICIENT)

    //低电压重新连接
    var LOW_VOLTS_RECONNECT = getTag("low_volts_reconnect", ParseType.TENTHS_COEFFICIENT)

    //低压告警
    var LOW_VOLTS_WARNING = getTag("low_volts_warning", ParseType.TENTHS_COEFFICIENT)

    //低压断开
    var LOW_VOLTS_DISCONNECT = getTag("low_volts_disconnect", ParseType.TENTHS_COEFFICIENT)

    private fun getTag(description: String, @ParseType parseType: String): String {
        return DeviceType.CTRL + ProtocolsConsts.SEPARATOR + description + ProtocolsConsts.SEPARATOR + parseType
    }

    //错误告警信息
    private val mCharStatusList = mutableListOf<BaseSelectEntity>()

    //电池类型
    private val mBatTypeList = mutableListOf<BaseSelectEntity>()

    init {
        mCharStatusList.add(BaseSelectEntity.createTvRes(R.string.ctrl_status_mppt, false, "02"))
        mCharStatusList.add(
            BaseSelectEntity.createTvRes(
                R.string.ctrl_status_equalization,
                false,
                "03"
            )
        )
        mCharStatusList.add(BaseSelectEntity.createTvRes(R.string.ctrl_status_boost, false, "04"))
        mCharStatusList.add(BaseSelectEntity.createTvRes(R.string.ctrl_status_float, false, "05"))

        mBatTypeList.add(BaseSelectEntity.createTvRes(R.string.ctrl_bat_user, false, "0000"))
        mBatTypeList.add(BaseSelectEntity.createTvRes(R.string.ctrl_bat_flooded, false, "0001"))
        mBatTypeList.add(BaseSelectEntity.createTvRes(R.string.ctrl_bat_sld, false, "0002"))
        mBatTypeList.add(BaseSelectEntity.createTvRes(R.string.ctrl_bat_gel, false, "0003"))
        mBatTypeList.add(BaseSelectEntity.createTvRes(R.string.ctrl_bat_lithium, false, "0004"))
        mBatTypeList.add(BaseSelectEntity.createTvRes(R.string.ctrl_bat_lithium_36v, false, "0005"))
        mBatTypeList.add(BaseSelectEntity.createTvRes(R.string.ctrl_bat_lithium_48v, false, "0006"))
    }

    fun charStatusList(): MutableList<BaseSelectEntity> {
        return mCharStatusList
    }

    fun ctrlBatTypeList(): MutableList<BaseSelectEntity> {
        return mBatTypeList
    }

    //获取充电状态
    fun getCharStatus(hexCode: String): Int {
        mCharStatusList.forEach { item ->
            if (item.hexTag.equals(hexCode, ignoreCase = true)) {
                return item.titleRes
            }
        }
        return R.string.text_device_default_title
    }


}