package com.renogy.device.rdplibrary.device.parse.type

import com.renogy.device.rdplibrary.device.entity.BaseParseEntity
import com.renogy.device.rdplibrary.device.entity.StringParseEntity

/**
 * @author Create by 17474 on 2024/11/12.
 * Email： lishuwentimor1994@163.com
 * Describe：系统电压解析
 */
class ParseSysVolts: BaseParseService() {

    override fun parse(hexResp: String): BaseParseEntity {
        val highBit = hexResp.substring(0, 2)
//        val lowBit = hexResp.substring(2, 4)
        return StringParseEntity(
            if (highBit == "FF") "AUTO" else highBit.toInt(16).toString(),
            hexResp
        )
    }
}