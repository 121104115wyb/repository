package com.renogy.device.rdplibrary.device.cmd

import com.renogy.device.rdplibrary.device.anotation.DeviceType

/**
 * @author Create by 17474 on 2024/11/11.
 * Email： lishuwentimor1994@163.com
 * Describe：设备命令
 */
object DevCmdFactory {

    private val mCmdService = mutableMapOf<@DeviceType String, BaseCmdService>()

    init {
        mCmdService[DeviceType.CTRL] = CtrlCmdImpl()
        mCmdService[DeviceType.INV] = InvCmdImpl()
        mCmdService[DeviceType.BAT] = BatCmdImpl()
        mCmdService[DeviceType.DCC] = DCCCmdImpl()
    }

    /**
     * 获取不同的设备命令
     * @param type 设备类型
     */
    fun getCmdImpl(@DeviceType type: String): BaseCmdService? {
        return mCmdService.getOrDefault(type, null)
    }
}