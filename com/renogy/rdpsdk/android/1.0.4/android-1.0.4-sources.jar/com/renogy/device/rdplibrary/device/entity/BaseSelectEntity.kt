package com.renogy.device.rdplibrary.device.entity

import com.renogy.device.rdplibrary.R
import com.renogy.device.rdplibrary.RdpApplication

/**
 * @author Create by 17474 on 2024/9/18.
 * Email： lishuwentimor1994@163.com
 * Describe：选择类型的实体类
 * @param title 显示内容
 * @param boSelect 是否选中
 * @param hexTag 这里进行统一，都用对应的16进制的实际值标识,一般是4位的16进制字符串
 * @param titleRes 需要进行国际化的内容和title不能同时使用
 * @param boUseTitle 是否使用title
 * @param count 这里一般表示时间，长度等，不建议使用
 */
open class BaseSelectEntity(
    var title: String = "",
    var boSelect: Boolean = false,
    var hexTag: String? = "",
    var titleRes: Int = R.string.text_device_default_title,
    var boUseTitle: Boolean = true,
    var count: Int = -1,
) {

    fun showTitle(): String {
        RdpApplication.instance()
        return if (boUseTitle) title else RdpApplication.instance().getString(titleRes)
    }

    companion object {

        /**
         * 默认的类型
         */
        fun createNormal(
            title: String, boSelect: Boolean = false, hexTag: String = ""
        ): BaseSelectEntity {
            return BaseSelectEntity(title, boSelect, hexTag)
        }

        /**
         * 适配多语言
         */
        fun createTvRes(titleRes: Int, boSelect: Boolean, hexTag: String = ""): BaseSelectEntity {
            return BaseSelectEntity("", boSelect, hexTag, titleRes, false)
        }

        /**
         * 创建int类型
         */
        fun createCount(title: String, count: Int, boSelect: Boolean): BaseSelectEntity {
            return BaseSelectEntity(
                title,
                boSelect,
                "",
                R.string.text_device_default_title,
                true,
                count
            )
        }

        /**
         * 创建int类型
         */
        fun createCountTag(
            title: String,
            count: Int,
            hexTag: String,
            boSelect: Boolean
        ): BaseSelectEntity {
            return BaseSelectEntity(
                title,
                boSelect,
                hexTag,
                R.string.text_device_default_title,
                true,
                count
            )
        }
    }


}