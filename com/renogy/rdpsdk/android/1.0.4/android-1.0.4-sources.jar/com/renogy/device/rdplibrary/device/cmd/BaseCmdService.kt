package com.renogy.device.rdplibrary.device.cmd

import com.renogy.device.rdplibrary.device.anotation.CmdType
import com.renogy.device.rdplibrary.device.entity.CmdEntity

/**
 * @author Create by 17474 on 2024/11/11.
 * Email： lishuwentimor1994@163.com
 * Describe：获取命令
 */
interface BaseCmdService {

    fun getCmd(tag: String, @CmdType cmdType: String, hexDevAddress: String?): CmdEntity

}