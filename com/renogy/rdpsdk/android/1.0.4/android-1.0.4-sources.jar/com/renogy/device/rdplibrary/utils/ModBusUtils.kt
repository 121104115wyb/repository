package com.renogy.device.rdplibrary.utils

import android.text.TextUtils
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.math.BigDecimal
import java.math.BigInteger
import java.math.RoundingMode
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.*
import kotlin.math.abs

/**
 * @author wyb
 * Date :2020/1/15 0015 9:48
 * Description: module bus 协议解析
 * 解析设备协议
 */
object ModBusUtils {
    /**
     * 计算CRC16校验码
     *
     * @param data 需要校验的字符串
     * @return 校验码
     * 例如 : 0103000C0008 输入后，获取的CRC校验码为 840F
     * 0103000A0001输入后， 获取的CRC校验码为A408
     */
    @JvmStatic
    fun getCrc(data: String): String {
        var data = data
        data = data.replace(" ", "")
        val len = data.length
        if (len % 2 != 0) {
            return "0000"
        }
        val num = len / 2
        val para = ByteArray(num)
        for (i in 0 until num) {
            val value = Integer.valueOf(data.substring(i * 2, 2 * (i + 1)), 16)
            para[i] = value.toByte()
        }
        return getCrc(para)
    }

    /**
     * 计算CRC16校验码
     *
     * @param bytes 字节数组
     * @return [String] 校验码
     * @since 1.0
     */
    @JvmStatic
    fun getCrc(bytes: ByteArray): String {
        //CRC寄存器全为1
        var CRC = 0x0000ffff
        //多项式校验值
        val POLYNOMIAL = 0x0000a001
        var i: Int
        var j: Int
        i = 0
        while (i < bytes.size) {
            CRC = CRC xor (bytes[i].toInt() and 0x000000ff)
            j = 0
            while (j < 8) {
                if (CRC and 0x00000001 != 0) {
                    CRC = CRC shr 1
                    CRC = CRC xor POLYNOMIAL
                } else {
                    CRC = CRC shr 1
                }
                j++
            }
            i++
        }
        //结果转换为16进制
        var result = Integer.toHexString(CRC).uppercase(Locale.getDefault())
        if (result.length != 4) {
            val sb = StringBuilder("0000")
            result = sb.replace(4 - result.length, 4, result).toString()
        }
        //交换高低位
        return result.substring(2, 4) + result.substring(0, 2)
    }

    /**
     * 16进制直接转换成为字符串(无需Unicode解码)
     * 68747470733a2f2f77656861726d6f6e792e67697465652e696f2f
     * 52425435304c46503438530000000000
     * 52425435304c4650343853
     * 696E666f 转成 “info”
     *
     * @param hexStr 16进制（Ascii）字符串
     * @return 返回 字符串 中文
     */
    @JvmStatic
    fun hexStr2AsciiStr(hexStr: String): String {
        if (TextUtils.isEmpty(hexStr)) return ""
        val output = StringBuilder()
        var i = 0
        while (i < hexStr.length) {
            val str = hexStr.substring(i, i + 2)
            output.append(str.toInt(16).toChar())
            i += 2
        }
        return output.toString().trim { it <= ' ' }
    }

    /**
     * "info"转成696E666f
     *
     * @param asciiStr ascii "info" 转16进制的string 数据
     * @return 转成16进制的数据
     */
    @JvmStatic
    fun ascii2HexStr(asciiStr: String): String {
        if (TextUtils.isEmpty(asciiStr)) return ""
        val sb = StringBuilder()
        val ch = asciiStr.toCharArray()
        for (c in ch) {
            sb.append(Integer.toHexString(c.code))
        }
        return sb.toString().uppercase(Locale.getDefault())
    }

    //求累加校验和
    @JvmStatic
    fun getAccumulateCheck(items: ByteArray?): Byte {
        if (items == null) return null!!.toByte()
        var num: Byte = 0
        for (i in items) {
            num = (num + i).toByte()
        }
        val mod = num.toInt() and 0xFF
        return mod.toByte()
    }

    /**
     * 16进制按位数反
     * hexStr的位数不能超过4位
     *
     * @param hexStr 16进制的数据
     * @return 按位取反, 数据位数补0
     */
    @JvmStatic
    fun getHexReconciliation(hexStr: String): String {
        val length = hexStr.length
        val hexNum = hexStr.toInt(16)
        val sb = StringBuilder()
        while (sb.length < length) {
            sb.append("F")
        }
        val reserve = hexNum.inv() and sb.toString().toInt(16)
        return String.format("%0" + length + "x", reserve)
    }

    //ota更新补全数据标志位,逆变器超过255从0开始，控制器从1开始
    @JvmStatic
    fun getOtaFillIn(lastHexIndex: String): String {
        var index = lastHexIndex.toInt(16)
        index = if (index == 255) {
            0
        } else {
            index + 1
        }
        var hexIndex = Integer.toHexString(index)
        if (hexIndex.length == 1) {
            hexIndex = "0$hexIndex"
        }
        //01+数据位+数据位按位取反
        hexIndex = "01" + hexIndex + getHexReconciliation(hexIndex)
        return hexIndex
    }

    /**
     * byte数组转成16进制字符串
     *
     * @param byte_array 数组
     * @return hexString
     */
    @JvmStatic
    fun toHexString(byte_array: ByteArray): String {
        val hexString = StringBuilder()
        if (byte_array.isEmpty()) return ""
        for (b in byte_array) {
            val v = b.toInt() and 0xFF
            val hv = Integer.toHexString(v)
            if (hv.length < 2) {
                hexString.append(0)
            }
            hexString.append(hv)
        }
        return hexString.toString().uppercase(Locale.getDefault())
    }

    /**
     * 合并多数组为单数组
     *
     * @param values 数组
     * @return 合并为单数组
     */
    fun byteMergerAll(vararg values: ByteArray): ByteArray {
        var lengthByte = 0
        for (value in values) {
            lengthByte += value.size
        }
        val allByte = ByteArray(lengthByte)
        var countLength = 0
        for (b in values) {
            System.arraycopy(b, 0, allByte, countLength, b.size)
            countLength += b.size
        }
        return allByte
    }


    @JvmStatic
    fun reverseHex(hexStr: String): String {
        if (hexStr.isEmpty()) return ""
        val length = hexStr.length / 4
        val stringBuilder = StringBuilder()
        for (it in length downTo 1) {
            stringBuilder.append(hexStr.substring((it - 1) * 4, it * 4))
        }
        return stringBuilder.toString();
    }

    /**
     * 获取错误码列表
     *
     * @param hex 16进制
     * @return 2进制字符串
     */
    @JvmStatic
    fun getErrorCodes(byte_str: String): List<String> {
        val errorCodes: MutableList<String> =
            ArrayList() //000E0000// 0000 0000 0000 1110 0000 0000 0000 0000
        val length = byte_str.length
        for (index in 0 until length) {
            if ("1" == byte_str.substring(index, index + 1)) {
                val errorType = (length - index - 1).toString()
                errorCodes.add(errorType)
            }
        }
        return errorCodes
    }


    /**
     * 获取错误码列表
     *
     * @param hex 16进制
     * @return 2进制字符串
     */
    @JvmStatic
    fun getErrorCodes(hex: String, type: String): MutableList<String> {
        val errorCodes: MutableList<String> =
            ArrayList() //000E0000// 0000 0000 0000 1110 0000 0000 0000 0000
        val error2BitsStr = hexToByte(hex)
        val length = error2BitsStr.length
        for (index in 0 until length) {
            if ("1" == error2BitsStr.substring(index, index + 1)) {
                val errorType = type + (length - index - 1)
                errorCodes.add(errorType)
            }
        }
        return errorCodes
    }

    /**
     * 获取带CRC校验码的命令，输入“300301010001”获取crc校验码
     *
     * @param dex16String 16进制的命令
     * @return 16进制crc校验码
     */
    @JvmStatic
    fun getCrcCmd(dex16String: String): String {
        return dex16String + getCrc(dex16String)
    }

    /**
     * 校验接收到的蓝牙命令的Crc是否正确
     *
     * @param hex_resp 16位crc返回命令码
     * @return true 表示正确 false 表示不正确
     */
    @JvmStatic
    fun checkCrc(hex_resp: String): Boolean {
        if (hex_resp.isEmpty() || hex_resp.length <= 10) return false
        val hexStr = hex_resp.trim { it <= ' ' }
        val hexCrc = hexStr.substring(hexStr.length - 4)
        val hexCmd = hexStr.substring(0, hexStr.length - 4)
        return hexCrc == getCrc(hexCmd)
    }

    //FF8302A101
    @JvmStatic
    fun checkErrCodes(hexResp: String): Boolean {
        return hexResp.length == 10 && hexResp.substring(2, 4) == "8302"
    }

    /**
     * byte 转 hex数据
     *
     * @param byteResp byte响应数据
     */
    @JvmStatic
    fun getHexResp(byteResp: ByteArray?): String {
        return byteResp?.let {
            val var1 = StringBuilder(byteResp.size)
            for (var2 in byteResp.indices) {
                var1.append(String.format("%02X", byteResp[var2]))
                if (var2 < byteResp.size - 1) {
                    var1.append(' ')
                }
            }
            val hexStr = var1.toString()
            hexStr.replace(" +".toRegex(), "").uppercase(Locale.getDefault())
        } ?: ""
    }

    /**
     * 获取设备的SKU
     *
     * @param hexRsp 16进制的响应
     * @return 16进制的ASCII转文字
     */
    @JvmStatic
    fun getDeviceSku(hexRsp: String): String {
        var hexResp = hexRsp.substring(0, hexRsp.length - 4)
        if (hexResp.length < 38) {
            return ""
        }
        while (hexResp.endsWith("00")) {
            hexResp = hexResp.substring(0, hexResp.length - 2)
        }
        val skuHexRsp = hexResp.substring(6)
        return if (!TextUtils.isEmpty(skuHexRsp)) {
            hexStr2AsciiStr(skuHexRsp).trim { it <= ' ' }.uppercase(Locale.getDefault())
        } else ""
    }

    /**
     * 16进制转Ascii
     *
     * @param hex       16进制的string字符串
     * @param upperCase 是否转义
     * @return string 类型的 ascii
     */
    @JvmStatic
    fun hex2Ascii(hex: String, upperCase: Boolean): String {
        if (TextUtils.isEmpty(hex)) return ""
        val str = hexStr2AsciiStr(hex).trim { it <= ' ' }
        return if (upperCase) str.uppercase(Locale.getDefault()) else str
    }

    /**
     * 16进制转Ascii
     *
     * @param hex 16进制的string字符串
     * @return string 类型的 ascii
     */
    @JvmStatic
    fun hex2Ascii(hex: String): String {
        return if (TextUtils.isEmpty(hex)) "" else hexStr2AsciiStr(hex).trim { it <= ' ' }
            .uppercase(Locale.getDefault())
    }

    /**
     * 电池的版本
     * 例如：30030456303244DE24
     * 取 6到14位 56303244 转Ascii为 V02D
     * 1.读取不到电池版本信息，或者电池版本信息返回（CRC校验）错误，显示为(空) "";
     * 2.读取到电池版本信息，但是解析成Ascii 不是V 开头的我们显示为 "--"
     * 3.Ascii解析规则：例如 V02D
     * 注意:解析不是V开头的我们前面加V 显示成：V0014;
     * (1)V后面的三位，其余无效
     * (2)第四位为16进制，需要转成10进制
     * (3)第二位和第三位后面分别添加小数点"."
     * (4)拼接显示 V0.2.13
     *
     * @param hex 16进制的数据
     * @return 显示给用户的数据
     */
    @JvmStatic
    fun getBatVer(hex: String): String {
        var hexName = hex2Ascii(hex)
        if (TextUtils.isEmpty(hexName)) return ""
        if (hexName.length < 4) return ""
        return if (hexName.startsWith("V")) {
            hexName = hexName.substring(0, 4)
            hexName.substring(0, 2) + "." + hexName[2] + "." + hex2Int(hexName.substring(3))
        } else {
            "V$hexName"
        }
    }

    /**
     * 16进制转10进制
     * 默认为0，长度不能超过8位
     *
     * @param hex 16进制字符串
     * @return 10进制的int类型数据
     */
    @JvmStatic
    fun hex2Int(hex: String): Int {
        return try {
            if (TextUtils.isEmpty(hex)) 0 else hex.toInt(16)
        } catch (e: NumberFormatException) {
            e.printStackTrace()
            0
        }
    }

    @JvmStatic
    fun intToHex(i: Int, hexLength: Int): String {
        val hex = Integer.toHexString(i)
        var count = hexLength - hex.length
        val stringBuilder = StringBuilder()
        while (count > 0) {
            stringBuilder.append("0")
            count--
        }
        return stringBuilder.toString() + hex
    }

    /**
     * 当hex数据超过 Integer.MAX_VALUE(0x80000000) 后，需要转成long型
     *
     * @param hex 16进制
     * @return long型
     */
    @JvmStatic
    fun hex2Long(hex: String): Long {
        return if (TextUtils.isEmpty(hex)) 0L else hex.toLong(16)
    }


    /**
     * 设备温度，hexStr一般为2位，最长为4位
     * @param hexStr 16进制数据
     */
    @JvmStatic
    fun getDevTemp(hexStr: String): Int {
        if (TextUtils.isEmpty(hexStr)) return 0
        val houseByte = hexToFullByte(hexStr)
        if (TextUtils.isEmpty(houseByte)) return 0
        //负数
        return if (houseByte.startsWith("1")) {
            -byteToDec(houseByte.substring(1))
        } else {
            //正数
            byteToDec(houseByte)
        }
    }

    /**
     * 获取不同模式下的温度
     *
     * @param celsius 摄氏度
     * @param boCelsius 是否是摄氏度
     * @return 不同模式下的温度
     */
    fun getModeTemp(celsius: Float, boCelsius: Boolean): Float {
        return if (boCelsius) {
            celsius
        } else {
            32 + celsius * 1.8f
        }
    }


    /**
     * 获取设备温度
     *
     * @param hexString 16进制数据
     * @return 温度
     */
    @JvmStatic
    private fun getTemp(hexString: String): String {
        if (TextUtils.isEmpty(hexString)) return ""
        val i = hex2Int(hexString)
        if (i == 128) {
            return "0"
        }
        return if (i < 128) i.toString() else (128 - i).toString()
    }

    @JvmStatic
    private fun wxTemp(temp: Int): String {
        if (temp == 0) return "0000"
        if (temp < 0) {
            val hexTemp = hexToFullByte(num2Hex2(abs(temp)))
            val dataBit = hexTemp.substring(1)
            return num2Hex4(byteToDec("1$dataBit"))
        } else {
            return num2Hex4(temp)
        }
    }

    /**
     * 16进制转2进制，不补0
     * hex 的长度最大支持8  "FFFFFFFF"
     *
     * @param hex 16进制
     * @return 2进制字符串
     */
    @JvmStatic
    fun hexToByte(hex: String): String {
        val i = hex.toLong(16)
        return java.lang.Long.toBinaryString(i)
    }

    /**
     * 16进制转2进制，并补全二进制的数据不足的前面补0
     *
     * @param hex 2位或者多位
     * @return 全部位数的二进制数据
     */
    @JvmStatic
    fun hexToFullByte(hex: String): String {
        if (TextUtils.isEmpty(hex)) return ""
        //假设16进制的数据位2位，我们转成二进制的数据就是8位
        val twoByteLength = hex.length * 4
        val twoStr = hexToByte(hex)
        if (twoStr.length < twoByteLength) {
            val stringBuilder = StringBuilder()
            for (index in 0 until twoByteLength - twoStr.length) {
                stringBuilder.append("0")
            }
            return stringBuilder.append(twoStr).toString()
        }
        return twoStr
    }

    //将file文件转换成Byte数组
    @JvmStatic
    fun getBytesByFile(pathStr: String): ByteArray {
        val file = File(pathStr)
        return try {
            val fis = FileInputStream(file)
            val bos = ByteArrayOutputStream(1000)
            val b = ByteArray(1000)
            var n: Int
            while (fis.read(b).also { n = it } != -1) {
                bos.write(b, 0, n)
            }
            fis.close()
            val data = bos.toByteArray()
            bos.close()
            data
        } catch (e: Exception) {
            e.printStackTrace()
            ByteArray(0)
        }
    }


    /**
     * @param s 校验字符串是否能转成float
     *  float true else false
     */
    @JvmStatic
    fun boFloat(s: String?): Boolean {
        return s?.let {
            if (s.isEmpty()) return false
            try {
                s.toFloat()
                return true
            } catch (e: Exception) {
                e.printStackTrace()
                return false
            }
        } ?: false
    }

    /**
     * 电池电芯的温度
     *
     * @param hex_resp 4位返回值
     * @return 带有正负值的电芯温度
     */
    @JvmStatic
    fun getCellTemp(hex_resp: String): Int {
        if (TextUtils.isEmpty(hex_resp)) return 0
        val bitResult = hexToFullByte(hex_resp)
        if (TextUtils.isEmpty(bitResult)) return 0
        return if (bitResult.startsWith("1")) byteToDec(bitResult) - 65536 else byteToDec(bitResult)
    }

    /**
     * 处理控制器电流
     *
     * @return 返回太阳能板流进控制器电流
     */
    @JvmStatic
    fun ctrlSolarAmps(hexResult: String): Int {
        return try {
            val amps = hexResult.toInt(16)
            if (amps >= 65535) 0 else amps
        } catch (e: Exception) {
            e.printStackTrace()
            0
        }
    }

    /**
     * 逆变器和电池的电流都需要使用这个方法来解析电流的数值
     *
     * @param hex_resp 4位的hex数据
     * @return 返回电池和逆变器的电流（带"+","-"号）
     */
    @JvmStatic
    fun getBatOrInvAmps(hex_resp: String): Long {
        if (TextUtils.isEmpty(hex_resp)) return 0
        val bitStr = hexToFullByte(hex_resp)
        if (TextUtils.isEmpty(bitStr)) return 0

        val result = bitStr.toLong(2)
        return if (bitStr.startsWith("1")) result - 65536 else result
    }

    /**
     * Dc的电流
     *
     * @param hex_resp 4位的16进制数据
     * @return 带有符号位的电流大小（未处理位数）
     */
//    @JvmStatic
//    fun getDcCurrent(hex_resp: String): Int {
//        return getBatOrInvAmps(hex_resp)
//    }

    /**
     * 二进制转换成十进制
     *
     * @param binarySource 二进制的字符串
     * @return int 十进制的结果
     */
    @JvmStatic
    fun byteToDec(binarySource: String): Int {
        if (TextUtils.isEmpty(binarySource)) return 0
        val bi = BigInteger(binarySource, 2) //转换为BigInteger类型
        return bi.toString().toInt() //转换成十进制
    }

    /**
     * int 10进制转 String 16进制
     * example ： int 10 = hex(String) "30";
     *
     * @param b 请求参数
     * @return 返回 String 类型的16进制的参数
     */
    @JvmStatic
    fun num2Hex1(b: Int): String {
        return String.format("%01x", b) //2表示需要两个16进行数
    }

    /**
     * int 10进制转 String 16进制
     * example ： int 10 = hex(String) "30";
     *
     * @param b 请求参数
     * @return 返回 String 类型的16进制的参数
     */
    fun num2Hex2(b: Int): String {
        return String.format("%02x", b) //2表示需要两个16进行数
    }

    /**
     * int 10进制转 String 16进制
     * example ： int 10 = hex(String) "0030";
     *
     * @param b 请求参数
     * @return 返回 String 类型的16进制的参数
     */
    @JvmStatic
    fun num2Hex4(b: Int): String {
        return String.format("%04x", b).uppercase(Locale.getDefault())
    }

    /**
     * int 10进制转 String 16进制
     * example ： int 10 = hex(String) "00000030";
     *
     * @param b 请求参数
     * @return 返回 String 类型的16进制的参数
     */
    fun num2Hex8(b: Int): String {
        return String.format("%08x", b)
    }

    /**
     * 取两位精度
     *
     * @return 精度后的String
     */
    @JvmStatic
    fun dfStr(`object`: Any?): String {
        CmdTagUtils.spitStr("", "")

        return dfStr("0.00", `object`)
    }

    /**
     * @param object 基本数据类型
     * @return 精度后的String
     */
    @JvmStatic
    fun dfStr(`object`: Any?, lastIndexOmitted: Boolean): String {
        return dfStr("0.00", `object`, lastIndexOmitted)
    }
    /**
     * @param pattern          精度
     * @param object           基本数据类型
     * @param lastIndexOmitted 最后一位为0是否舍弃,true 舍弃，else 保留
     * @return 精度后的String
     */
    /**
     * @param pattern 精度
     * @param object  基本数据类型
     * @return 精度后的String
     */
    @JvmOverloads
    @JvmStatic
    fun dfStr(pattern: String?, `object`: Any?, lastIndexOmitted: Boolean = true): String {
        if (`object` == null) return "--"
        val df = DecimalFormat(pattern)
        val symbols = DecimalFormatSymbols()
        symbols.decimalSeparator = '.'
        df.decimalFormatSymbols = symbols
        val formatResult = df.format(`object`)
        if (!TextUtils.isEmpty(formatResult) && formatResult.contains(".")) {
            val startArray =
                formatResult.split("\\.".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
            var endResult = startArray[1]
            return if (endResult.length < 2) {
                formatResult
            } else {
                if (endResult.endsWith("0") && lastIndexOmitted) {
                    endResult = endResult.substring(0, endResult.length - 1)
                }
                startArray[0] + "." + endResult
            }
        }
        return formatResult
    }

    /**
     * 取三位精度
     *
     * @return 精度后的String
     */
    @JvmStatic
    @JvmOverloads
    fun dfFloat(`object`: Float, newScale: Int = 3): Float {
        return BigDecimal(`object`.toDouble()).setScale(newScale, RoundingMode.HALF_UP).toFloat()
    }

    /**
     * 去除开头的0
     * @param str 字符串
     */
    fun removeLeadingZeros(str: String): String {
        // 使用正则表达式去除开头的“0”
        return str.replaceFirst("^0+".toRegex(), "")
    }


    @JvmStatic
    fun simpleCheck(hexResp: String?): Boolean {
        if (TextUtils.isEmpty(hexResp) || hexResp!!.length <= 10) return false
        if (hexResp.substring(2, 4) == "8302") return false
        val dataBitsCount = hexResp.substring(4, 6).toInt(16) + 6
        return hexResp.length > dataBitsCount
    }


    //获取固件版本0001 00 08
    fun getDevVer(hexResp: String): String {
        if (TextUtils.isEmpty(hexResp) || hexResp.length != 8) return ""
        val num1 = hexResp.substring(0, 4).toInt(16)
        val num2 = hexResp.substring(4, 6).toInt(16)
        val num3 = hexResp.substring(6, 8).toInt(16)
        return "$num1.$num2.$num3"
    }

    /**
     * 获取带有符号的数
     */
    fun getSignNum(hexResp: String): Long {
        if (hexResp.length % 2 != 0) return 0
        var removeZero = hexResp
        if (hexResp.length > 4) {
            removeZero = removeLeadingZeros(hexResp)
        }
        if (TextUtils.isEmpty(removeZero)) {
            return 0
        }
        val firstIndex = hexResp.substring(0, 1)
        val firstIndexByte = hexToFullByte(firstIndex)
        if (firstIndexByte.startsWith("1")) {
            return when (removeZero.length) {
                1 -> {
                    -(hexResp.toLong(16).xor(0xF) + 1)
                }

                2 -> {
                    -(hexResp.toLong(16).xor(0xFF) + 1)
                }

                3 -> {
                    -(hexResp.toLong(16).xor(0xFFF) + 1)
                }

                4 -> {
                    -(hexResp.toLong(16).xor(0xFFFF) + 1)
                }

                5 -> {
                    -(hexResp.toLong(16).xor(0xFFFFF) + 1)
                }

                6 -> {
                    -(hexResp.toLong(16).xor(0xFFFFFF) + 1)
                }

                7 -> {
                    -(hexResp.toLong(16).xor(0xFFFFFFF) + 1)
                }

                8 -> {
                    -(hexResp.toLong(16).xor(0xFFFFFFFF) + 1)
                }

                else -> {
                    0
                }
            }
        } else {
            return hexResp.toLong(16)
        }
    }


}