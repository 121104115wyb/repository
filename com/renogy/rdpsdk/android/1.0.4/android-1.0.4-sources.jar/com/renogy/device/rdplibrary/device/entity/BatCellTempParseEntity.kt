package com.renogy.device.rdplibrary.device.entity

import com.renogy.device.rdplibrary.utils.ModBusUtils

/**
 * 电池电芯温度解析
 * result()电芯温度
 */
class BatCellTempParseEntity(hexResp: String) :
    BaseParseEntity(hexResp) {
    var batCellTempNum = 0

    override fun result(): String {
        val batCellTempList = batCellTempLists()
        if (batCellTempList.size == 0 || batCellTempList.size != batCellTempNum) {
            return "--"
        }
        return batCellTempList.toString()
    }

    public fun batCellTempLists(): MutableList<String> {
        try {
            batCellTempNum = hexResp.substring(0, 4).toInt()
            val tempList = mutableListOf<String>()
            for (cellVolt in 1 until batCellTempNum + 1) {
                val cellTemp = hexResp.substring(
                    4 * cellVolt,
                    4 * (cellVolt + 1)
                )
                tempList.add(ModBusUtils.dfStr(ModBusUtils.getCellTemp(cellTemp) * 0.1f))
            }
            return tempList
        } catch (e: Exception) {
            e.printStackTrace()
            return mutableListOf()
        }
    }


//    //电池电芯温度
//    public fun batCellTempArrays(): FloatArray? {
//        return getBatTempArray(hexResp)
//    }

//    /**
//     * 获取电池温度
//     * @param hexTemp 16进制的电池温度返回值
//     * @return 电池的最大，最小温度数组，也可能为null
//     */
//    private fun getBatTempArray(hexTemp: String): FloatArray? {
//        if (TextUtils.isEmpty(hexTemp)) return null
//        try {
//            batCellTempNum = hexTemp.substring(0, 4).toInt(16)
//            if (batCellTempNum == 0) return null
//            //最大，最小的存在同一个数组中
//            val tempArray = floatArrayOf(
//                ABSOLUTE_ZERO_TEMPERATURE,
//                ABSOLUTE_ZERO_TEMPERATURE
//            )
//            for (index in 0 until batCellTempNum) {
//                val hexRsp: String = hexTemp.substring(4 * (1 + index), 4 * (index + 2))
//                val curTemp = ModBusUtils.getCellTemp(hexRsp) * 0.1f
//                if (index == 0) {
//                    tempArray[0] = curTemp
//                    tempArray[1] = curTemp
//                    continue
//                }
//
//                //存储最大的
//                if (tempArray[0] < curTemp) {
//                    tempArray[0] = curTemp
//                }
//
//                //存储最小的
//                if (tempArray[1] > curTemp) {
//                    tempArray[1] = curTemp
//                }
//            }
//
//            return tempArray
//        } catch (e: Exception) {
//            e.printStackTrace()
//            return null
//        }
//    }
}