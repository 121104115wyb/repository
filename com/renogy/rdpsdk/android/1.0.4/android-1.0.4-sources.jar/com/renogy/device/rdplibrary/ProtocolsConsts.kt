package com.renogy.device.rdplibrary

import com.renogy.device.rdplibrary.device.anotation.CmdType
import com.renogy.device.rdplibrary.device.anotation.DeviceType
import com.renogy.device.rdplibrary.device.cmd.DevCmdFactory
import com.renogy.device.rdplibrary.device.entity.BaseParseEntity
import com.renogy.device.rdplibrary.device.entity.CmdEntity
import com.renogy.device.rdplibrary.device.parse.DevRespFactory
import com.renogy.device.rdplibrary.utils.CmdTagUtils
import com.renogy.device.rdplibrary.utils.ModBusUtils

/**
 * @author Create by 17474 on 2024/11/11.
 * Email： lishuwentimor1994@163.com
 * Describe：Off-grid device protocols
 */
object ProtocolsConsts {
    const val RF_CODE = "03"
    const val GENERAL_CODE = "FF"
    const val SEPARATOR = "#"
    const val SWITCH_ON = 1
    const val SWITCH_OFF = 2

    /**
     * @param deviceType 设备类型
     * @param hexDevAddress 16进制设备地址
     * @param cmdTag 不同设备的命令标识
     * @param cmdType 命令类型
     * @return 不同设备的指令
     */
    private fun getCmd(
        @DeviceType deviceType: String,
        cmdTag: String,
        @CmdType cmdType: String = CmdType.READ,
        hexDevAddress: String? = ""
    ): CmdEntity {
        val cmdService = DevCmdFactory.getCmdImpl(deviceType)
        return cmdService?.getCmd(cmdTag, cmdType, hexDevAddress)?:CmdEntity("","")
    }

    /**
     * @param deviceType 设备类型
     * @param hexDevAddress 16进制设备地址
     * @param cmdTag 不同设备的命令标识
     * @return 不同设备的指令
     */
    fun getReadCmd(
        @DeviceType deviceType: String,
        cmdTag: String,
        hexDevAddress: String? = ""
    ): CmdEntity {
        return getCmd(deviceType, cmdTag, CmdType.READ, hexDevAddress)
    }

    /**
     * @param cmdTag 命令标识
     * @param resp 响应值
     */
    fun parseResp(cmdTag: String, resp: String): BaseParseEntity {
        return CmdTagUtils.spitStr(cmdTag, SEPARATOR)?.let {
            if (it.size != 3) return BaseParseEntity("")
            val devType = it[0]
            val parseType = it[2]
            DevRespFactory.getRespImpl(devType)?.parse(cmdTag, resp, parseType)
        } ?: BaseParseEntity("")
    }

    /**
     * @param cmdTag 命令标识
     * @param byte 响应值
     */
    fun parseResp(cmdTag: String, byte: ByteArray): BaseParseEntity {
        return CmdTagUtils.spitStr(cmdTag, SEPARATOR)?.let {
            if (it.size != 3) return BaseParseEntity("")
            val devType = it[0]
            val parseType = it[2]
            DevRespFactory.getRespImpl(devType)
                ?.parse(cmdTag, ModBusUtils.getHexResp(byte), parseType)
        } ?: BaseParseEntity("")
    }
}