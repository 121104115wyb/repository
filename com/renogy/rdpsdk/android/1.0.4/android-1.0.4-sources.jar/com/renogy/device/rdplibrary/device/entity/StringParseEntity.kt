package com.renogy.device.rdplibrary.device.entity

/**
 * @author Create by 17474 on 2024/11/12.
 * Email： lishuwentimor1994@163.com
 * Describe：String 解析结果
 * @param value 解析后的数据
 * @param hexResp 解析前的响应值
 */
class StringParseEntity(var value: String? = null, hexResp: String) :
    BaseParseEntity(hexResp) {

    override fun result(): String {
        return value ?: let {
            "--"
        }
    }
}