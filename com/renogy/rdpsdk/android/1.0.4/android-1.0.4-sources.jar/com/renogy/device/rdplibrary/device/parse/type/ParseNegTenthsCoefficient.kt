package com.renogy.device.rdplibrary.device.parse.type

import com.renogy.device.rdplibrary.device.entity.BaseParseEntity
import com.renogy.device.rdplibrary.device.entity.FloatParseEntity
import com.renogy.device.rdplibrary.utils.ModBusUtils

/**
 * @author Create by 17474 on 2024/11/13.
 * Email： lishuwentimor1994@163.com
 * Describe：系数解析，系数0.1,有符号数
 */
class ParseNegTenthsCoefficient:BaseParseService (){

    override fun parse(hexResp: String): BaseParseEntity {
        return FloatParseEntity(ModBusUtils.getBatOrInvAmps(hexResp) * 0.1f, hexResp)
    }
}