package com.renogy.device.rdplibrary.device.parse

import com.renogy.device.rdplibrary.device.anotation.DeviceType
import com.renogy.device.rdplibrary.device.ctrl.CtrlConsts
import com.renogy.device.rdplibrary.device.entity.BaseParseEntity
import com.renogy.device.rdplibrary.device.entity.ErrorParseEntity
import com.renogy.device.rdplibrary.device.parse.type.ParseSelect
import com.renogy.device.rdplibrary.device.parse.type.ParseSelect2BitsLower

/**
 * @author Create by 17474 on 2024/11/12.
 * Email： lishuwentimor1994@163.com
 * Describe：控制器解析
 */
class CtrlRespImpl : BaseRespService {

    override fun parse(cmdTag: String, hexResp: String, parseType: String): BaseParseEntity {
        //数据截止位置
        val subEndIndex = ParseConsts.getSubEndIndex(hexResp)
        //待解析的数据
        val parseHexResp = hexResp.substring(6, subEndIndex)
        //解析服务
        val parseService = ParseFactory.getParseImpl(parseType)
        parseService?.type = DeviceType.CTRL
        when (cmdTag) {
            CtrlConsts.CHARGING_STATUS -> {
                if (parseService is ParseSelect2BitsLower) {
                    parseService.selectList = CtrlConsts.charStatusList()
                }
            }

            CtrlConsts.BATTERY_TYPE -> {
                if (parseService is ParseSelect) {
                    parseService.selectList = CtrlConsts.ctrlBatTypeList()
                }
            }
        }
        return parseService?.parse(parseHexResp) ?: ErrorParseEntity(
            "parse error:\ncmdTag:$cmdTag\nhexResp:$hexResp\nparseType:$parseType ",
            ""
        )
    }
}