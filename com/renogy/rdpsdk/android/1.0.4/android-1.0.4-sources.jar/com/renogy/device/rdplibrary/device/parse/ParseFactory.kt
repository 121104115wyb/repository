package com.renogy.device.rdplibrary.device.parse

import com.renogy.device.rdplibrary.device.anotation.ParseType
import com.renogy.device.rdplibrary.device.parse.type.BaseParseService
import com.renogy.device.rdplibrary.device.parse.type.ParseAscii
import com.renogy.device.rdplibrary.device.parse.type.ParseBatCellTemp
import com.renogy.device.rdplibrary.device.parse.type.ParseBatCellVolts
import com.renogy.device.rdplibrary.device.parse.type.ParseBit
import com.renogy.device.rdplibrary.device.parse.type.ParseBoolean
import com.renogy.device.rdplibrary.device.parse.type.ParseCoefficient
import com.renogy.device.rdplibrary.device.parse.type.ParseNegPercentilesCoefficient
import com.renogy.device.rdplibrary.device.parse.type.ParseNegTenthsCoefficient
import com.renogy.device.rdplibrary.device.parse.type.ParseNot
import com.renogy.device.rdplibrary.device.parse.type.ParsePercentilesCoefficient
import com.renogy.device.rdplibrary.device.parse.type.ParseSelect
import com.renogy.device.rdplibrary.device.parse.type.ParseSelect2BitsHigher
import com.renogy.device.rdplibrary.device.parse.type.ParseSelect2BitsLower
import com.renogy.device.rdplibrary.device.parse.type.ParseSysVolts
import com.renogy.device.rdplibrary.device.parse.type.ParseTemp
import com.renogy.device.rdplibrary.device.parse.type.ParseTemp2BitsHigher
import com.renogy.device.rdplibrary.device.parse.type.ParseTemp2BitsLower
import com.renogy.device.rdplibrary.device.parse.type.ParseTenthsCoefficient
import com.renogy.device.rdplibrary.device.parse.type.ParseThousandthCoefficient
import com.renogy.device.rdplibrary.device.parse.type.ParseVersion

/**
 * @author Create by 17474 on 2024/11/12.
 * Email： lishuwentimor1994@163.com
 * Describe：数据解析
 */
object ParseFactory {

    private val mParseService = mutableMapOf<String, BaseParseService>()

    init {
        mParseService[ParseType.PARSE_2_BITS_LOW_TEMP] = ParseTemp2BitsLower()
        mParseService[ParseType.PARSE_2_BITS_HIGHER_TEMP] = ParseTemp2BitsHigher()
        mParseService[ParseType.PARSE_NOT] = ParseNot()
        mParseService[ParseType.PARSE_ASCII] = ParseAscii()
        mParseService[ParseType.COEFFICIENT] = ParseCoefficient()
        mParseService[ParseType.SYS_VOLTS] = ParseSysVolts()
        mParseService[ParseType.TENTHS_COEFFICIENT] = ParseTenthsCoefficient()
        mParseService[ParseType.PERCENTILES_COEFFICIENT] = ParsePercentilesCoefficient()
        mParseService[ParseType.THOUSANDTH_COEFFICIENT] = ParseThousandthCoefficient()
        mParseService[ParseType.SELECT] = ParseSelect()
        mParseService[ParseType.SELECT_2_BITS_HIGHER] = ParseSelect2BitsHigher()
        mParseService[ParseType.SELECT_2_BITS_LOWER] = ParseSelect2BitsLower()
        mParseService[ParseType.BIT] = ParseBit()
        mParseService[ParseType.BOOLEAN] = ParseBoolean()
        mParseService[ParseType.NEG_TENTHS_COEFFICIENT] = ParseNegTenthsCoefficient()
        mParseService[ParseType.NEG_PERCENTILES_COEFFICIENT] = ParseNegPercentilesCoefficient()
        mParseService[ParseType.PARSE_TEMP] = ParseTemp()
        mParseService[ParseType.BAT_CELL_VOLTS] = ParseBatCellVolts()
        mParseService[ParseType.BAT_CELL_TEMP] = ParseBatCellTemp()
        mParseService[ParseType.DEV_VERSION] = ParseVersion()

    }

    /**
     * 获取不同的设备的解析服务
     * @param parseType 解析类型
     */
    fun getParseImpl(parseType: String?): BaseParseService? {
        return mParseService.getOrDefault(parseType, null)
    }

}