package com.renogy.device.rdplibrary.device.parse.type

import com.renogy.device.rdplibrary.device.entity.BaseParseEntity
import com.renogy.device.rdplibrary.device.entity.IntParseEntity
import com.renogy.device.rdplibrary.utils.ModBusUtils

/**
 * @author Create by 17474 on 2024/11/13.
 * Email： lishuwentimor1994@163.com
 * Describe：低八位解析温度
 */
class ParseTemp2BitsLower:BaseParseService() {
    override fun parse(hexResp: String): BaseParseEntity {
        return IntParseEntity(ModBusUtils.getDevTemp(hexResp.substring(2, 4)), hexResp)
    }
}