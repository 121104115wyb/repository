package com.renogy.device.rdplibrary

import android.app.Application

/**
 * @author Create by 17474 on 2024/11/13.
 * Email： lishuwentimor1994@163.com
 * Describe：
 */
open class RdpApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        rdpApp = this
    }

    companion object {
        private lateinit var rdpApp: RdpApplication

        fun instance(): RdpApplication {
            return rdpApp
        }
    }


}