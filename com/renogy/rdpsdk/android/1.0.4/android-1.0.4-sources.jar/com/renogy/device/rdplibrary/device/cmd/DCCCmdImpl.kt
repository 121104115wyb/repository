package com.renogy.device.rdplibrary.device.cmd

import android.text.TextUtils
import com.renogy.device.rdplibrary.ProtocolsConsts.GENERAL_CODE
import com.renogy.device.rdplibrary.ProtocolsConsts.RF_CODE
import com.renogy.device.rdplibrary.device.anotation.CmdType
import com.renogy.device.rdplibrary.device.dcc.DCCConsts
import com.renogy.device.rdplibrary.device.entity.CmdEntity
import com.renogy.device.rdplibrary.utils.ModBusUtils

/**
 * @author Create by 17474 on 2024/12/3.
 * Email： lishuwentimor1994@163.com
 * Describe：dcc命令
 */
class DCCCmdImpl : BaseCmdService {

    override fun getCmd(tag: String, cmdType: String, hexDevAddress: String?): CmdEntity {
        val pduCmd = when (tag) {
            DCCConsts.DEVICE_ADDRESS -> {
                "001A0001"
            }

            DCCConsts.SKU -> {
                "000C0008"
            }

            DCCConsts.FIRMWARE_VERSION -> {
                "00160002"
            }

            DCCConsts.SOFTWARE_VERSION -> {
                "00140002"
            }

            DCCConsts.BATTERY_TYPE -> {
                "E0040001"
            }

            DCCConsts.SYSTEM_VOLTS -> {
                "E0030001"
            }

            DCCConsts.CHARGE_STATUS -> {
                "01200001"
            }

            DCCConsts.AUXILIARY_BATTERY_VOLTS -> {
                "01010001"
            }

            DCCConsts.AUXILIARY_BATTERY_CHARGE_AMPS -> {
                "01020001"
            }

            DCCConsts.AUXILIARY_BATTERY_CHARGE_WATTS -> {
                "01090001"
            }

            DCCConsts.STARTER_BATTERY_VOLTS -> {
                "01040001"
            }

            DCCConsts.STARTER_BATTERY_AMPS -> {
                "01050001"
            }

            DCCConsts.SOLAR_CHARGE_VOLTS -> {
                "01070001"
            }

            DCCConsts.SOLAR_CHARGE_AMPS -> {
                "01080001"
            }

            DCCConsts.TOTAL_KWH_GENERATED -> {
                "011C0002"
            }

            DCCConsts.AUXILIARY_BATTERY_TEMPERATURE, DCCConsts.DC_DC_MPPT_TEMPERATURE -> {
                "01030001"
            }

            DCCConsts.MAX_CHARGE_AMPS -> {
                "E0010001"
            }

            DCCConsts.BOOST_VOLTS -> {
                "E0080001"
            }

            DCCConsts.FLOAT_VOLTS -> {
                "E0090001"
            }

            DCCConsts.EQUALIZATION_VOLTS -> {
                "E0070001"
            }

            DCCConsts.BOOST_DURATION -> {
                "E0080001"
            }

            DCCConsts.EQUALIZATION_INTERVAL -> {
                "E0130001"
            }

            DCCConsts.OVER_VOLTS_SHUTDOWN -> {
                "E0050001"
            }

            DCCConsts.UNDER_VOLTS_RECOVER -> {
                "E00B0001"
            }

            DCCConsts.LOW_VOLTS_WARNING -> {
                "E00C0001"
            }

            DCCConsts.LOW_VOLTS_DISCONNECT -> {
                "E00D0001"
            }

            DCCConsts.EQUALIZATION_DURATION -> {
                "E0110001"
            }

            else -> {
                ""
            }
        }
        var devAddress = GENERAL_CODE
        if (!TextUtils.isEmpty(hexDevAddress)) {
            devAddress = hexDevAddress!!
        }
        val unCrcCmd = devAddress + (if (cmdType == CmdType.READ) RF_CODE else RF_CODE) + pduCmd
        val cmd = ModBusUtils.getCrcCmd(unCrcCmd)
        return CmdEntity(cmd, tag)

    }
}