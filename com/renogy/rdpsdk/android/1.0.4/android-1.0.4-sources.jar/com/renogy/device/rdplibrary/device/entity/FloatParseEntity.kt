package com.renogy.device.rdplibrary.device.entity

import com.renogy.device.rdplibrary.utils.ModBusUtils

/**
 * @author Create by 17474 on 2024/11/12.
 * Email： lishuwentimor1994@163.com
 * Describe：解析成float数值
 */
class FloatParseEntity(var float: Float? = null, hexResp: String) :
    BaseParseEntity(hexResp ) {

    override fun result(): String {
        return float?.let {
            ModBusUtils.dfStr(float)
        } ?: let {
            "--"
        }
    }
}