package com.renogy.device.rdplibrary.device.parse

import com.renogy.device.rdplibrary.device.anotation.DeviceType

/**
 * @author Create by 17474 on 2024/11/12.
 * Email： lishuwentimor1994@163.com
 * Describe：设备响应值解析
 */
object DevRespFactory {

    private val mRespService = mutableMapOf<String, BaseRespService>()

    init {
        mRespService[DeviceType.CTRL] = CtrlRespImpl()
        mRespService[DeviceType.INV] = InvRespImpl()
        mRespService[DeviceType.BAT] = BatRespImp()
        mRespService[DeviceType.DCC] = DCCRespImpl()
    }

    /**
     * 获取不同的设备的解析服务
     * @param deviceType 设备类型
     */
    fun getRespImpl(deviceType: String?): BaseRespService? {
        return mRespService.getOrDefault(deviceType, null)
    }

}