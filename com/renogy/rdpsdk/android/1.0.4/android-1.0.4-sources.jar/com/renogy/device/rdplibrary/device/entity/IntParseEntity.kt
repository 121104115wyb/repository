package com.renogy.device.rdplibrary.device.entity

/**
 * @author Create by 17474 on 2024/11/12.
 * Email： lishuwentimor1994@163.com
 * Describe：解析成int数值
 */
class IntParseEntity (var int: Int? = null, hexResp: String) :
    BaseParseEntity(hexResp ) {

    override fun result(): String {
        return int?.toString() ?: let {
            "--"
        }
    }
}