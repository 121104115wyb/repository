package com.renogy.device.rdplibrary.device.parse.type

import com.renogy.device.rdplibrary.device.anotation.DeviceType
import com.renogy.device.rdplibrary.device.entity.BaseParseEntity
import com.renogy.device.rdplibrary.device.entity.StringParseEntity
import com.renogy.device.rdplibrary.utils.ModBusUtils

/**
 *
 * @Description TODO
 * @Author: LiShuWen
 * @Email: lishuwentimor1994@163.com
 * @CreateTime 2025年12月15日 10:09:26
 */
class ParseVersion : BaseParseService() {
    override fun parse(hexResp: String): BaseParseEntity {
        return when(type){
            DeviceType.CTRL,DeviceType.DCC-> {
                StringParseEntity(ModBusUtils.getDevVer(hexResp), hexResp)
            }
            else ->StringParseEntity(ModBusUtils.hex2Ascii(hexResp), hexResp)
        }
    }
}