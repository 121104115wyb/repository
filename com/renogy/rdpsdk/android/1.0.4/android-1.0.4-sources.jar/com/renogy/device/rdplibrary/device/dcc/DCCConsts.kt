package com.renogy.device.rdplibrary.device.dcc

import com.renogy.device.rdplibrary.ProtocolsConsts
import com.renogy.device.rdplibrary.R
import com.renogy.device.rdplibrary.device.anotation.DeviceType
import com.renogy.device.rdplibrary.device.anotation.ParseType
import com.renogy.device.rdplibrary.device.entity.BaseSelectEntity

/**
 * @author Create by 17474 on 2024/12/3.
 * Email： lishuwentimor1994@163.com
 * Describe：dcdc
 */
object DCCConsts {
    //设备地址
    var DEVICE_ADDRESS = getTag("device_address", ParseType.PARSE_NOT)

    //设备的SKU
    var SKU = getTag("sku", ParseType.PARSE_ASCII)

    //固件版本
    var FIRMWARE_VERSION = getTag("firmware_version", ParseType.DEV_VERSION)

    //软件版本
    var SOFTWARE_VERSION = getTag("software_version", ParseType.DEV_VERSION)

    //电池类型
    var BATTERY_TYPE = getTag("battery_type", ParseType.SELECT)

    //系统电压
    var SYSTEM_VOLTS = getTag("system_volts", ParseType.SYS_VOLTS)

    //充电状态
    var CHARGE_STATUS = getTag("charge_status", ParseType.SYS_VOLTS)

    //辅助电池电压
    var AUXILIARY_BATTERY_VOLTS = getTag("auxiliary_battery_volts", ParseType.TENTHS_COEFFICIENT)

    //辅助电池充电电流
    var AUXILIARY_BATTERY_CHARGE_AMPS =
        getTag("auxiliary_battery_charge_amps", ParseType.NEG_PERCENTILES_COEFFICIENT)

    //辅助电池充电功率
    var AUXILIARY_BATTERY_CHARGE_WATTS =
        getTag("auxiliary_battery_charge_watts", ParseType.COEFFICIENT)

    //起动器电池电压
    var STARTER_BATTERY_VOLTS = getTag("starter_battery_volts", ParseType.TENTHS_COEFFICIENT)

    //起动器电池电流
    var STARTER_BATTERY_AMPS = getTag("starter_battery_amps", ParseType.PERCENTILES_COEFFICIENT)

    //起动器电池电流
    var SOLAR_CHARGE_VOLTS = getTag("solar_charge_volts", ParseType.TENTHS_COEFFICIENT)

    //起动器电池电流
    var SOLAR_CHARGE_AMPS = getTag("solar_charge_amps", ParseType.PERCENTILES_COEFFICIENT)

    //产生的总 kWh
    var TOTAL_KWH_GENERATED = getTag("total_kwh_generated", ParseType.THOUSANDTH_COEFFICIENT)

    //辅助电池温度
    var AUXILIARY_BATTERY_TEMPERATURE =
        getTag("auxiliary_battery_temperature", ParseType.PARSE_2_BITS_LOW_TEMP)

    //dcc温度
    var DC_DC_MPPT_TEMPERATURE =
        getTag("dc_dc_mppt_temperature", ParseType.PARSE_2_BITS_HIGHER_TEMP)

    //最大充电电流
    var MAX_CHARGE_AMPS = getTag("max_charge_amps", ParseType.PERCENTILES_COEFFICIENT)

    //升压电压
    var BOOST_VOLTS = getTag("boost_volts", ParseType.TENTHS_COEFFICIENT)

    //浮动电压
    var FLOAT_VOLTS = getTag("float_volts", ParseType.TENTHS_COEFFICIENT)

    //均衡电压
    var EQUALIZATION_VOLTS = getTag("equalization_volts", ParseType.TENTHS_COEFFICIENT)

    //提升持续时间
    var BOOST_DURATION = getTag("boost_duration", ParseType.COEFFICIENT)

    //均衡间隔时间
    var EQUALIZATION_INTERVAL = getTag("equalization_interval", ParseType.COEFFICIENT)

    //过电压停机
    var OVER_VOLTS_SHUTDOWN = getTag("over_volts_shutdown", ParseType.TENTHS_COEFFICIENT)

    //低电压恢复电压
    var UNDER_VOLTS_RECOVER = getTag("under_volts_recover", ParseType.TENTHS_COEFFICIENT)

    //低电压警告
    var LOW_VOLTS_WARNING = getTag("low_volts_warning", ParseType.TENTHS_COEFFICIENT)

    //低电压断开
    var LOW_VOLTS_DISCONNECT = getTag("low_volts_disconnect", ParseType.TENTHS_COEFFICIENT)

    //均衡持续时间
    var EQUALIZATION_DURATION = getTag("equalization_duration", ParseType.COEFFICIENT)

    private fun getTag(description: String, @ParseType parseType: String): String {
        return DeviceType.DCC + ProtocolsConsts.SEPARATOR + description + ProtocolsConsts.SEPARATOR + parseType
    }

    //错误告警信息
    private val mCharStatusList = mutableListOf<BaseSelectEntity>()

    //电池类型
    private val mBatTypeList = mutableListOf<BaseSelectEntity>()

    init {
        mCharStatusList.add(
            BaseSelectEntity.createTvRes(
                R.string.dcc_status_not_charging,
                false,
                "00"
            )
        )
        mCharStatusList.add(BaseSelectEntity.createTvRes(R.string.dcc_status_bulk, false, "02"))
        mCharStatusList.add(
            BaseSelectEntity.createTvRes(
                R.string.dcc_status_equalization,
                false,
                "03"
            )
        )
        mCharStatusList.add(BaseSelectEntity.createTvRes(R.string.dcc_status_boost, false, "04"))
        mCharStatusList.add(BaseSelectEntity.createTvRes(R.string.dcc_status_float, false, "05"))
        mCharStatusList.add(
            BaseSelectEntity.createTvRes(
                R.string.dcc_status_current_limit,
                false,
                "06"
            )
        )
        mCharStatusList.add(BaseSelectEntity.createTvRes(R.string.dcc_status_direct, false, "08"))

        mBatTypeList.add(BaseSelectEntity.createTvRes(R.string.dcc_bat_user, false, "0000"))
        mBatTypeList.add(BaseSelectEntity.createTvRes(R.string.dcc_bat_flooded, false, "0001"))
        mBatTypeList.add(BaseSelectEntity.createTvRes(R.string.dcc_bat_sld, false, "0002"))
        mBatTypeList.add(BaseSelectEntity.createTvRes(R.string.dcc_bat_gel, false, "0003"))
        mBatTypeList.add(BaseSelectEntity.createTvRes(R.string.dcc_bat_lithium, false, "0004"))
    }

    fun charStatusList(): MutableList<BaseSelectEntity> {
        return mCharStatusList
    }

    fun dccBatTypeList(): MutableList<BaseSelectEntity> {
        return mBatTypeList
    }

    //获取充电状态
    fun getCharStatus(hexCode: String): Int {
        mCharStatusList.forEach { item ->
            if (item.hexTag.equals(hexCode, ignoreCase = true)) {
                return item.titleRes
            }
        }
        return R.string.text_device_default_title
    }

}