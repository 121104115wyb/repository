package com.renogy.device.rdplibrary.device.anotation

import androidx.annotation.StringDef
import com.renogy.device.rdplibrary.device.anotation.CmdType.Companion.READ
import com.renogy.device.rdplibrary.device.anotation.CmdType.Companion.WRITE

/**
 * @author Create by 17474 on 2024/11/11.
 * Email： lishuwentimor1994@163.com
 * Describe：命令类型
 */
@Target(AnnotationTarget.VALUE_PARAMETER, AnnotationTarget.TYPE)
@StringDef(
    READ, WRITE
)
@Retention(AnnotationRetention.SOURCE)
annotation class CmdType {
    companion object {
        const val READ = "read"
        const val WRITE = "write"
    }
}
