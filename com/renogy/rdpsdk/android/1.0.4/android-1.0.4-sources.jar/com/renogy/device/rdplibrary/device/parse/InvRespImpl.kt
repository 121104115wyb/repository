package com.renogy.device.rdplibrary.device.parse

import com.renogy.device.rdplibrary.device.entity.BaseParseEntity
import com.renogy.device.rdplibrary.device.entity.ErrorParseEntity
import com.renogy.device.rdplibrary.device.inv.InvConsts
import com.renogy.device.rdplibrary.device.parse.type.ParseSelect

/**
 * @author Create by 17474 on 2024/11/12.
 * Email： lishuwentimor1994@163.com
 * Describe：逆变器解析
 */
class InvRespImpl : BaseRespService {

    override fun parse(cmdTag: String, hexResp: String, parseType: String): BaseParseEntity {
        //数据截止位置
        val subEndIndex = ParseConsts.getSubEndIndex(hexResp)
        //待解析的数据
        val parseHexResp = hexResp.substring(6, subEndIndex)
        //解析服务
        val parseService = ParseFactory.getParseImpl(parseType)
        when (cmdTag) {
            InvConsts.POWER_SAVING_MODE -> {
                if (parseService is ParseSelect) {
                    parseService.selectList = InvConsts.powerSavingModeList()
                }
            }
        }
        return parseService?.parse(parseHexResp) ?: ErrorParseEntity(
            "parse error:\ncmdTag:$cmdTag\nhexResp:$hexResp\nparseType:$parseType ",
            ""
        )
    }
}