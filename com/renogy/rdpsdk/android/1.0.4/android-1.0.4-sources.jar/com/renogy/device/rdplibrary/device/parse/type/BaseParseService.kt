package com.renogy.device.rdplibrary.device.parse.type

import com.renogy.device.rdplibrary.device.entity.BaseParseEntity

/**
 * @author Create by 17474 on 2024/11/12.
 * Email： lishuwentimor1994@163.com
 * Describe：解析服务
 */
abstract class BaseParseService (var sku :String = "",
                                 var type:String = ""){


    /**
     * @param hexResp 响应值
     * @return 解析后的数据
     */
    abstract fun parse(hexResp: String): BaseParseEntity
}