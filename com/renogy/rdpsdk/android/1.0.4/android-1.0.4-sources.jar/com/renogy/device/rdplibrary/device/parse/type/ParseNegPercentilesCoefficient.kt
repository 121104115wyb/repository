package com.renogy.device.rdplibrary.device.parse.type

import com.renogy.device.rdplibrary.device.entity.BaseParseEntity
import com.renogy.device.rdplibrary.device.entity.FloatParseEntity
import com.renogy.device.rdplibrary.utils.ModBusUtils

/**
 * @author Create by 17474 on 2024/11/13.
 * Email： lishuwentimor1994@163.com
 * Describe：带符号位的系数解析，系数为0.01
 */
class ParseNegPercentilesCoefficient : BaseParseService() {

    override fun parse(hexResp: String): BaseParseEntity {
        return FloatParseEntity(ModBusUtils.getSignNum(hexResp) * 0.01f, hexResp)
    }
}