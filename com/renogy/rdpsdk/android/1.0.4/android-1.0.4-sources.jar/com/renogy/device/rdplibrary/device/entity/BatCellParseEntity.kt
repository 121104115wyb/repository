package com.renogy.device.rdplibrary.device.entity

import com.renogy.device.rdplibrary.utils.ModBusUtils

//电池电芯电压解析
class BatCellParseEntity(hexResp: String) :
    BaseParseEntity(hexResp) {
    var batCellNum = 0

    override fun result(): String {
        val batCellList = batCellLists()
        if (batCellList.size == 0 || batCellList.size != batCellNum) {
            return "--"
        }
//        val stringBuilder = StringBuilder()
//        stringBuilder.append("[")
//        for (cellVolt in 0 until  batCellNum) {
//            stringBuilder.append("Cell" + (cellVolt + 1) + ":" + batCellList[cellVolt]).append("&")
//        }
//        stringBuilder.append("]")
//        val removeIndex = stringBuilder.lastIndexOf("&")
//        stringBuilder.replace(removeIndex , removeIndex+1, "")
        return batCellList.toString()
    }

    public fun batCellLists(): MutableList<String> {
        try {
            batCellNum = hexResp.substring(0, 4).toInt()
            val voltsList = mutableListOf<String>()
            for (cellVolt in 1 until batCellNum + 1) {
                val result = ModBusUtils.hex2Int(
                    hexResp.substring(
                        4 * cellVolt,
                        4 * (cellVolt + 1)
                    )
                ) * 0.1
                voltsList.add(ModBusUtils.dfStr(result))
            }
            return voltsList
        } catch (e: Exception) {
            e.printStackTrace()
            return mutableListOf()
        }
    }

}