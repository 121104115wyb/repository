package com.renogy.device.rdplibrary.device.parse.type

import com.renogy.device.rdplibrary.device.entity.BaseParseEntity
import com.renogy.device.rdplibrary.device.entity.StringParseEntity
import com.renogy.device.rdplibrary.utils.ModBusUtils

/**
 * @author Create by 17474 on 2024/11/12.
 * Email： lishuwentimor1994@163.com
 * Describe：ASCII解析
 */
class ParseAscii : BaseParseService() {
    override fun parse(hexResp: String): BaseParseEntity {
        return StringParseEntity(ModBusUtils.hex2Ascii(hexResp), hexResp)
    }
}