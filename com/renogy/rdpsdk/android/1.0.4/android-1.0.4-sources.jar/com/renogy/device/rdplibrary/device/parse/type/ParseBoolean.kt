package com.renogy.device.rdplibrary.device.parse.type

import com.renogy.device.rdplibrary.ProtocolsConsts
import com.renogy.device.rdplibrary.R
import com.renogy.device.rdplibrary.RdpApplication
import com.renogy.device.rdplibrary.device.entity.BaseParseEntity
import com.renogy.device.rdplibrary.device.entity.StringParseEntity

/**
 * @author Create by 17474 on 2024/11/13.
 * Email： lishuwentimor1994@163.com
 * Describe：布尔值解析
 */
class ParseBoolean : BaseParseService() {

    override fun parse(hexResp: String): BaseParseEntity {

        return StringParseEntity(
            RdpApplication.instance()
                .getString(if (hexResp.toInt(16) == ProtocolsConsts.SWITCH_ON) R.string.text_switch_on else R.string.text_switch_off),
            hexResp
        )
    }
}