package com.renogy.device.rdplibrary.device.parse.type

import com.renogy.device.rdplibrary.device.entity.BaseParseEntity
import com.renogy.device.rdplibrary.device.entity.FloatParseEntity

/**
 * @author Create by 17474 on 2024/11/12.
 * Email： lishuwentimor1994@163.com
 * Describe：系数解析 系数为0.001
 */
class ParseThousandthCoefficient  : BaseParseService() {

    override fun parse(hexResp: String): BaseParseEntity {
        return FloatParseEntity(hexResp.toInt(16) * 0.001f, hexResp)
    }
}