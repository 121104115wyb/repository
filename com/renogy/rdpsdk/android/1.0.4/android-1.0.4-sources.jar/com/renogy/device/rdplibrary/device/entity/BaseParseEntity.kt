package com.renogy.device.rdplibrary.device.entity

/**
 * @author Create by 17474 on 2024/11/12.
 * Email： lishuwentimor1994@163.com
 * Describe：解析
 * @param hexResp 16进制的响应值
 */
open class BaseParseEntity(var hexResp: String) {

    open fun result():String{
        return ""
    }

}