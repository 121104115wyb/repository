package com.renogy.device.rdplibrary.device.cmd

import android.text.TextUtils
import com.renogy.device.rdplibrary.ProtocolsConsts.GENERAL_CODE
import com.renogy.device.rdplibrary.ProtocolsConsts.RF_CODE
import com.renogy.device.rdplibrary.device.anotation.CmdType
import com.renogy.device.rdplibrary.device.bat.BatConsts
import com.renogy.device.rdplibrary.device.entity.CmdEntity
import com.renogy.device.rdplibrary.utils.ModBusUtils

/**
 * @author Create by 17474 on 2024/11/11.
 * Email： lishuwentimor1994@163.com
 * Describe：developing
 */
class BatCmdImpl : BaseCmdService {

    override fun getCmd(tag: String, cmdType: String, hexDevAddress: String?): CmdEntity {
        val pduCmd = when (tag) {
            BatConsts.DEVICE_ADDRESS -> {
                "14670001"
            }

            BatConsts.SKU -> {
                "14020008"
            }

            BatConsts.FIRMWARE_VERSION -> {
                "140A0002"
            }

            BatConsts.BATTERY_VOLTS -> {
                "13B30001"
            }

            BatConsts.BATTERY_AMPS -> {
                "13B20001"
            }

            BatConsts.REMAIN_CAPACITY -> {
                "13B40002"
            }

            BatConsts.TOTAL_CAPACITY -> {
                "13B60002"
            }

            BatConsts.BATTERY_CELLS_NUMBER -> {
                "13880001"
            }

            BatConsts.BATTERY_TEMPERATURE_CELLS_NUMBER -> {
                "13990001"
            }

            BatConsts.BATTERY_CELLS_VOLTS -> {
                "13880011"
            }

            BatConsts.BATTERY_CELLS_TEMPERATURE -> {
                "13990011"
            }

            BatConsts.HEATER_MODE_STATUS -> {
                "13F30001"
            }

            else -> {
                ""
            }
        }
        var devAddress = GENERAL_CODE
        if (!TextUtils.isEmpty(hexDevAddress)) {
            devAddress = hexDevAddress!!
        }
        val unCrcCmd = devAddress+(if (cmdType == CmdType.READ) RF_CODE else RF_CODE )+pduCmd
        val cmd = ModBusUtils.getCrcCmd(unCrcCmd)
        return CmdEntity(cmd, tag)
    }
}