package com.renogy.device.rdplibrary.device

import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGatt.GATT_SUCCESS
import java.util.HashMap

/**
 * @author Create by 17474 on 2021/5/19.
 * Email： lishuwentimor1994@163.com
 * Describe：蓝牙的基本信息配置
 */
object BleConsts {
    /**
     * 蓝牙服务通道的uuid
     */
    const val RECEIVER_SERVICE_UUID = "0000fff0-0000-1000-8000-00805f9b34fb"

    /**
     * 蓝牙服务通道的特征值的uuid
     */
    const val RECEIVER_CHART_UUID = "0000fff1-0000-1000-8000-00805f9b34fb"

    /**
     * 发送命令给蓝牙，蓝牙服务的uuid
     */
    const val SEND_SERVICE_UUID = "0000ffd0-0000-1000-8000-00805f9b34fb"

    /**
     * 发送命令给蓝牙，数据的特征值uuid
     */
    const val SEND_CHART_UUID = "0000ffd1-0000-1000-8000-00805f9b34fb"

    /**
     * 蓝牙服务通道的uuid
     */
//    const val RECEIVER_SERVICE_UUID = "00001150-0000-1000-8000-00805F9B34FB"
//
//    /**
//     * 蓝牙服务通道的特征值的uuid
//     */
//    const val RECEIVER_CHART_UUID = "00001150-0000-1000-8000-00805F9B34FB"
//
//    /**
//     * 发送命令给蓝牙，蓝牙服务的uuid
//     */
//    const val SEND_SERVICE_UUID = "00001120-0000-1000-8000-00805F9B34FB"
//
//    /**
//     * 发送命令给蓝牙，数据的特征值uuid
//     */
//    const val SEND_CHART_UUID = "00001140-0000-1000-8000-00805F9B34FB"


    private val BLE_MAP = HashMap<String, String>()

    //蓝牙过滤规则
    val BLE_FILTER = listOf(
        "RTM",
        "BT",
        "RNG",
    )

    fun bleContains(bleName: String?): Boolean {
        bleName?.let { name ->
            BLE_FILTER.onEach {
                if (name.startsWith(it, ignoreCase = true)) {
                    return true
                }
            }
        }
        return false
    }

    fun getBleName(bleMac: String?): String {
        return bleMac?.let {
            BLE_MAP[it]
        } ?: let {
            ""
        }
    }

    fun addBle(bleMac: String,bleName: String){
        BLE_MAP[bleMac] = bleName
    }

    /**
     * 校验mtu是否成功
     * @param status mtu状态码
     */
    fun boMtuSuccess(status: Int): Boolean {
        return status == BluetoothGatt.GATT_SUCCESS
    }
}