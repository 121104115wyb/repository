package com.renogy.device.rdplibrary.device.cmd

import android.text.TextUtils
import com.renogy.device.rdplibrary.utils.ModBusUtils
import com.renogy.device.rdplibrary.ProtocolsConsts.GENERAL_CODE
import com.renogy.device.rdplibrary.ProtocolsConsts.RF_CODE
import com.renogy.device.rdplibrary.device.anotation.CmdType
import com.renogy.device.rdplibrary.device.ctrl.CtrlConsts
import com.renogy.device.rdplibrary.device.entity.CmdEntity

/**
 * @author Create by 17474 on 2024/11/11.
 * Email： lishuwentimor1994@163.com
 * Describe：控制器的指令
 */
class CtrlCmdImpl : BaseCmdService {

    override fun getCmd(tag: String, cmdType: String, hexDevAddress: String?): CmdEntity {
        val pduCmd = when (tag) {
            CtrlConsts.DEVICE_ADDRESS -> {
                "001A0001"
            }

            CtrlConsts.SKU -> {
                "000C0008"
            }

            CtrlConsts.FIRMWARE_VERSION -> {
                "00160002"
            }

            CtrlConsts.SOFTWARE_VERSION -> {
                "00140002"
            }

            CtrlConsts.ESTIMATED_SOC -> {
                "01000001"
            }

            CtrlConsts.BATTERY_CHARGING_VOLTS -> {
                "01010001"
            }

            CtrlConsts.BATTERY_CHARGING_AMPS -> {
                "01020001"
            }

            CtrlConsts.CTRL_TEMP, CtrlConsts.BATTERY_TEMP -> {
                "01030001"
            }

            CtrlConsts.LOAD_VOLTS -> {
                "01040001"
            }

            CtrlConsts.LOAD_AMPS -> {
                "01050001"
            }

            CtrlConsts.SOLAR_VOLTS -> {
                "01070001"
            }

            CtrlConsts.SOLAR_AMPS -> {
                "01080001"
            }

            CtrlConsts.TOTAL_POWER_GENERATION -> {
                "011C0002"
            }

            CtrlConsts.CHARGING_STATUS, CtrlConsts.DC_LOAD_OUTPUT -> {
                "01200001"
            }

            CtrlConsts.BATTERY_TYPE -> {
                "E0040001"
            }

            CtrlConsts.SYSTEM_VOLTS -> {
                "E0030001"
            }

            CtrlConsts.LOAD_STATUS -> {
                "E01D0001"
            }

            CtrlConsts.BOOST_VOLTS -> {
                "E0080001"
            }

            CtrlConsts.FLOAT_VOLTS -> {
                "E0090001"
            }

            CtrlConsts.EQUALIZATION_VOLTS -> {
                "E0070001"
            }

            CtrlConsts.BOOST_DURATION -> {
                "E0120001"
            }

            CtrlConsts.LOW_VOLTS_RECONNECT -> {
                "E00B0001"
            }

            CtrlConsts.LOW_VOLTS_WARNING -> {
                "E00C0001"
            }

            CtrlConsts.LOW_VOLTS_DISCONNECT -> {
                "E00D0001"
            }

            else -> {
                ""
            }
        }
        var devAddress = GENERAL_CODE
        if (!TextUtils.isEmpty(hexDevAddress)) {
            devAddress = hexDevAddress!!
        }
        val unCrcCmd = devAddress + (if (cmdType == CmdType.READ) RF_CODE else RF_CODE) + pduCmd
        val cmd = ModBusUtils.getCrcCmd(unCrcCmd)
        return CmdEntity(cmd, tag)
    }

}