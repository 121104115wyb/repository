package com.renogy.device.rdplibrary.device.anotation

import androidx.annotation.StringDef
import com.renogy.device.rdplibrary.device.anotation.ParseType.Companion.BAT_CELL_TEMP
import com.renogy.device.rdplibrary.device.anotation.ParseType.Companion.BAT_CELL_VOLTS
import com.renogy.device.rdplibrary.device.anotation.ParseType.Companion.BIT
import com.renogy.device.rdplibrary.device.anotation.ParseType.Companion.BOOLEAN
import com.renogy.device.rdplibrary.device.anotation.ParseType.Companion.COEFFICIENT
import com.renogy.device.rdplibrary.device.anotation.ParseType.Companion.NEG_PERCENTILES_COEFFICIENT
import com.renogy.device.rdplibrary.device.anotation.ParseType.Companion.NEG_TENTHS_COEFFICIENT
import com.renogy.device.rdplibrary.device.anotation.ParseType.Companion.PARSE_2_BITS_HIGHER_TEMP
import com.renogy.device.rdplibrary.device.anotation.ParseType.Companion.PARSE_2_BITS_LOW_TEMP
import com.renogy.device.rdplibrary.device.anotation.ParseType.Companion.PARSE_ASCII
import com.renogy.device.rdplibrary.device.anotation.ParseType.Companion.PARSE_NOT
import com.renogy.device.rdplibrary.device.anotation.ParseType.Companion.PARSE_TEMP
import com.renogy.device.rdplibrary.device.anotation.ParseType.Companion.PERCENTILES_COEFFICIENT
import com.renogy.device.rdplibrary.device.anotation.ParseType.Companion.SELECT
import com.renogy.device.rdplibrary.device.anotation.ParseType.Companion.SELECT_2_BITS_HIGHER
import com.renogy.device.rdplibrary.device.anotation.ParseType.Companion.SELECT_2_BITS_LOWER
import com.renogy.device.rdplibrary.device.anotation.ParseType.Companion.SYS_VOLTS
import com.renogy.device.rdplibrary.device.anotation.ParseType.Companion.TENTHS_COEFFICIENT
import com.renogy.device.rdplibrary.device.anotation.ParseType.Companion.THOUSANDTH_COEFFICIENT

/**
 * @author Create by 17474 on 2024/11/12.
 * Email： lishuwentimor1994@163.com
 * Describe：解析类型
 */
@StringDef(
    PARSE_NOT,
    PARSE_ASCII,
    COEFFICIENT,
    TENTHS_COEFFICIENT,
    PERCENTILES_COEFFICIENT,
    THOUSANDTH_COEFFICIENT,
    SELECT,
    SELECT_2_BITS_HIGHER,
    SELECT_2_BITS_LOWER,
    BIT, SYS_VOLTS,
    PARSE_2_BITS_HIGHER_TEMP,
    PARSE_2_BITS_LOW_TEMP,
    BOOLEAN,
    NEG_TENTHS_COEFFICIENT,
    NEG_PERCENTILES_COEFFICIENT,
    PARSE_TEMP,
    BAT_CELL_VOLTS,
    BAT_CELL_TEMP,
)
@Retention(AnnotationRetention.SOURCE)
annotation class ParseType {

    companion object {
        //解析两位的温度低位
        const val PARSE_TEMP = "parse_temp"

        //解析两位的温度高位
        const val PARSE_2_BITS_HIGHER_TEMP = "parse_2_bits_higher_temp"

        //解析两位的温度低位
        const val PARSE_2_BITS_LOW_TEMP = "parse_2_bits_low_temp"

        //不解析,版本，地址等
        const val PARSE_NOT = "parse_not"

        //解析成ASCII
        const val PARSE_ASCII = "parse_ascii"

        //系数为1
        const val COEFFICIENT = "coefficient"

        //系统电压
        const val SYS_VOLTS = "sys_volts"

        //十分位，解析结果需要乘0.1
        const val TENTHS_COEFFICIENT = "tenths_coefficient"

        //百分位，解析结果需要乘0.01
        const val PERCENTILES_COEFFICIENT = "percentiles_coefficient"

        //千分位，解析结果需要乘0.001
        const val THOUSANDTH_COEFFICIENT = "thousandth_coefficient"

        //选项，默认四位
        const val SELECT = "select"

        //选项,高8位
        const val SELECT_2_BITS_HIGHER = "select_2_bits_higher"

        //选项,低8位
        const val SELECT_2_BITS_LOWER = "select_2_bits_lower"

        //布尔值解析
        const val BOOLEAN = "boolean"

        //带符号的十分位系数解析
        const val NEG_TENTHS_COEFFICIENT = "neg_tenths_coefficient"

        //带符号的百分位系数解析
        const val NEG_PERCENTILES_COEFFICIENT = "neg_percentiles_coefficient"

        //带符号的百分位系数解析
        const val BAT_CELL_VOLTS = "bat_cell_volts"

        //带符号的百分位系数解析
        const val BAT_CELL_TEMP = "bat_cell_temp"

        //BIT位默认就是所有的bit选项解析
        const val BIT = "bit"
        //解析版本
        const val DEV_VERSION = "dev_version"
    }
}
