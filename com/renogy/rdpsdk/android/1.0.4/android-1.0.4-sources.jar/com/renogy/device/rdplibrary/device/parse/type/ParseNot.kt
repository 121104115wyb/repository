package com.renogy.device.rdplibrary.device.parse.type

import com.renogy.device.rdplibrary.device.entity.BaseParseEntity
import com.renogy.device.rdplibrary.device.entity.StringParseEntity

/**
 * @author Create by 17474 on 2024/11/12.
 * Email： lishuwentimor1994@163.com
 * Describe：不解析
 */
class ParseNot : BaseParseService() {

    override fun parse(hexResp: String): BaseParseEntity {
        return StringParseEntity(hexResp, hexResp)
    }
}