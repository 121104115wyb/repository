package com.renogy.device.rdplibrary.device.parse.type

import com.renogy.device.rdplibrary.device.entity.BaseParseEntity
import com.renogy.device.rdplibrary.device.entity.IntParseEntity
import com.renogy.device.rdplibrary.utils.ModBusUtils

/**
 * @author Create by 17474 on 2024/11/13.
 * Email： lishuwentimor1994@163.com
 * Describe：温度解析，默认解析2个字节的长度
 */
class ParseTemp : BaseParseService() {
    override fun parse(hexResp: String): BaseParseEntity {
        return IntParseEntity(ModBusUtils.getDevTemp(hexResp), hexResp)
    }
}