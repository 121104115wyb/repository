package com.renogy.device.rdplibrary.device.anotation

import androidx.annotation.StringDef
import com.renogy.device.rdplibrary.device.anotation.DeviceType.Companion.BAT
import com.renogy.device.rdplibrary.device.anotation.DeviceType.Companion.CTRL
import com.renogy.device.rdplibrary.device.anotation.DeviceType.Companion.DCC
import com.renogy.device.rdplibrary.device.anotation.DeviceType.Companion.INV

/**
 * @author Create by 17474 on 2024/11/11.
 * Email： lishuwentimor1994@163.com
 * Describe：设备类型
 */
@Target(AnnotationTarget.VALUE_PARAMETER, AnnotationTarget.TYPE)
@StringDef(
    CTRL, BAT, INV, DCC
)
@Retention(AnnotationRetention.SOURCE)
annotation class DeviceType {

    companion object {
        const val CTRL = "ctrl"
        const val BAT = "bat"
        const val INV = "inv"
        const val DCC = "dcc"
    }
}
