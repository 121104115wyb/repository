package com.renogy.device.rdplibrary.device.cmd

import android.text.TextUtils
import com.renogy.device.rdplibrary.utils.ModBusUtils
import com.renogy.device.rdplibrary.ProtocolsConsts.GENERAL_CODE
import com.renogy.device.rdplibrary.ProtocolsConsts.RF_CODE

import com.renogy.device.rdplibrary.device.anotation.CmdType
import com.renogy.device.rdplibrary.device.entity.CmdEntity
import com.renogy.device.rdplibrary.device.inv.InvConsts

/**
 * @author Create by 17474 on 2024/11/11.
 * Email： lishuwentimor1994@163.com
 * Describe：逆变器命令
 */
class InvCmdImpl : BaseCmdService {

    override fun getCmd(tag: String, cmdType: String, hexDevAddress: String?): CmdEntity {

        val pduCmd = when (tag) {
            InvConsts.DEVICE_ADDRESS -> {
                "100D0001"
            }

            InvConsts.SKU -> {
                "10D70008"
            }

            InvConsts.SN -> {
                "10100009"
            }

            InvConsts.FIRMWARE_VERSION -> {
                "10DF0008"
            }

            InvConsts.INPUT_VOLTS -> {
                "0FA00001"
            }

            InvConsts.INPUT_AMPS -> {
                "0FA10001"
            }

            InvConsts.OUTPUT_VOLTS -> {
                "0FA20001"
            }

            InvConsts.OUTPUT_AMPS -> {
                "0FA30001"
            }

            InvConsts.OUTPUT_FREQUENCY -> {
                "0FA40001"
            }

            InvConsts.BATTERY_VOLTS -> {
                "0FA50001"
            }

            InvConsts.DEVICE_TEMPERATURE -> {
                "0FA60001"
            }

            InvConsts.POWER_SAVING_MODE -> {
                "115C0001"
            }

            InvConsts.BEEP_SWITCH -> {
                "10050001"
            }

            InvConsts.NG_BONDING_ENABLE -> {
                "100E0001"
            }

            InvConsts.OVER_VOLTS_PROTECTION -> {
                "11640001"
            }

            InvConsts.OVER_VOLTS_RESTORE -> {
                "11650001"
            }

            InvConsts.OVER_DISCHARGE_SHUTDOWN -> {
                "114F0001"
            }

            InvConsts.LOW_VOLTS_WARNING -> {
                "114E0001"
            }

            InvConsts.LOW_VOLTS_RESTORE -> {
                "11660001"
            }

            else -> {
                ""
            }
        }
        var devAddress = GENERAL_CODE
        if (!TextUtils.isEmpty(hexDevAddress)) {
            devAddress = hexDevAddress!!
        }
        val unCrcCmd = devAddress + (if (cmdType == CmdType.READ) RF_CODE else RF_CODE) + pduCmd
        val cmd = ModBusUtils.getCrcCmd(unCrcCmd)
        return CmdEntity(cmd, tag)
    }

}