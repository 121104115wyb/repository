package com.renogy.device.rdplibrary.utils

/**
 * @author Create by 17474 on 2024/11/12.
 * Email： lishuwentimor1994@163.com
 * Describe：命令工具类
 */
object CmdTagUtils {

    /**
     * @param spitStr 需要分割的字符串
     * @param separator 分隔符
     * @return 分割结果
     */
    fun spitStr(spitStr: String, separator: String): List<String>? {
        return if (spitStr.contains(separator)) {
            spitStr.split(separator)
        } else null
    }
}