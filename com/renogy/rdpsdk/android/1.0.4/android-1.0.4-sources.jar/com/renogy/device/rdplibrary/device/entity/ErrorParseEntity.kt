package com.renogy.device.rdplibrary.device.entity

/**
 * @author Create by 17474 on 2024/11/13.
 * Email： lishuwentimor1994@163.com
 * Describe：解析出错了
 * @param errMsg 错误信息
 */
class ErrorParseEntity(private var errMsg: String = "", hexResp: String) : BaseParseEntity(hexResp) {

    override fun result(): String {
        return errMsg
    }
}