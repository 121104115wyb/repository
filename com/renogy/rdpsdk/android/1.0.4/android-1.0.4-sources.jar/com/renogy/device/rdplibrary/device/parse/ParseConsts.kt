package com.renogy.device.rdplibrary.device.parse

/**
 * @author Create by 17474 on 2024/11/12.
 * Email： lishuwentimor1994@163.com
 * Describe：解析常量方法
 */
object ParseConsts {

    //绝对零度
    const val ABSOLUTE_ZERO_TEMPERATURE = -273.15f

    /**
     * @param hexResp 响应值
     * 待解析数据的截止位
     */
    fun getSubEndIndex(hexResp: String): Int {
        if (hexResp.length < 4) return 0
        return 6 + hexResp.substring(4, 6).toInt(16) * 2
    }
}