package com.renogy.device.rdplibrary.device.entity

/**
 * @author Create by 17474 on 2024/11/11.
 * Email： lishuwentimor1994@163.com
 * Describe：指令
 * @param cmd 指令
 * @param cmdTag 标识
 */
class CmdEntity(var cmd: String, var cmdTag: String)
