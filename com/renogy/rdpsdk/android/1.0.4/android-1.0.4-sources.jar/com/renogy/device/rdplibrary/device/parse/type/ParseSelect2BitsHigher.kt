package com.renogy.device.rdplibrary.device.parse.type

import com.renogy.device.rdplibrary.device.entity.BaseParseEntity
import com.renogy.device.rdplibrary.device.entity.BaseSelectEntity
import com.renogy.device.rdplibrary.device.entity.StringParseEntity

/**
 * @author Create by 17474 on 2024/11/12.
 * Email： lishuwentimor1994@163.com
 * Describe：选项解析高8位
 */
class ParseSelect2BitsHigher(
    var selectList: MutableList<BaseSelectEntity>? = null,
) : BaseParseService() {

    override fun parse(hexResp: String): BaseParseEntity {
        return StringParseEntity(
            selectList?.find { it.hexTag == hexResp.substring(2, 4) }?.showTitle(),
            hexResp
        )
    }
}