package com.renogy.device.rdplibrary.device.inv

import com.renogy.device.rdplibrary.ProtocolsConsts
import com.renogy.device.rdplibrary.device.anotation.DeviceType
import com.renogy.device.rdplibrary.device.anotation.ParseType
import com.renogy.device.rdplibrary.device.entity.BaseSelectEntity

/**
 * @author Create by 17474 on 2024/11/11.
 * Email： lishuwentimor1994@163.com
 * Describe：Inverter
 * 目前只支持读取数据,每个参数的命令标识组成为"deviceType#parameterName#ParseType"
 * 比如；读取逆变器设备地址的命令tag为"inv#device_address#parse_not"
 * 由此可以得知，这是逆变器的命令,参数的名称为设备地址,解析方式为不解析
 * 后续可能开放更多的逆变器指令
 */
object InvConsts {
    var DEVICE_ADDRESS = getTag("device_address", ParseType.PARSE_NOT)
    var SKU = getTag("sku", ParseType.PARSE_ASCII)
    var SN = getTag("sn", ParseType.PARSE_ASCII)
    var FIRMWARE_VERSION = getTag("firmware_version", ParseType.PARSE_ASCII)
    var INPUT_VOLTS = getTag("input_volts", ParseType.TENTHS_COEFFICIENT)
    var INPUT_AMPS = getTag("input_amps", ParseType.PERCENTILES_COEFFICIENT)
    var OUTPUT_VOLTS = getTag("output_volts", ParseType.TENTHS_COEFFICIENT)
    var OUTPUT_AMPS = getTag("output_amps", ParseType.NEG_PERCENTILES_COEFFICIENT)
    var OUTPUT_FREQUENCY = getTag("output_frequency", ParseType.PERCENTILES_COEFFICIENT)
    var BATTERY_VOLTS = getTag("battery_volts", ParseType.TENTHS_COEFFICIENT)
    var DEVICE_TEMPERATURE = getTag("device_temperature", ParseType.COEFFICIENT)
    var POWER_SAVING_MODE = getTag("power_saving_mode", ParseType.SELECT)
    var BEEP_SWITCH = getTag("beep_switch", ParseType.BOOLEAN)
    var NG_BONDING_ENABLE = getTag("ng_bonding_enable", ParseType.BOOLEAN)
    var OVER_VOLTS_PROTECTION = getTag("over_volts_protection", ParseType.TENTHS_COEFFICIENT)
    var OVER_VOLTS_RESTORE = getTag("over_volts_restore", ParseType.TENTHS_COEFFICIENT)
    var OVER_DISCHARGE_SHUTDOWN = getTag("over_discharge_shutdown", ParseType.TENTHS_COEFFICIENT)
    var LOW_VOLTS_WARNING = getTag("low_volts_warning", ParseType.TENTHS_COEFFICIENT)
    var LOW_VOLTS_RESTORE = getTag("low_volts_restore", ParseType.TENTHS_COEFFICIENT)

    private fun getTag(description: String, @ParseType parseType: String): String {
        return DeviceType.INV + ProtocolsConsts.SEPARATOR + description + ProtocolsConsts.SEPARATOR + parseType
    }

    //错误告警信息
    private val mPowerSavingModeList = mutableListOf<BaseSelectEntity>()

    init {
        mPowerSavingModeList.add(BaseSelectEntity.createNormal("forbid", false, "0000"))
        mPowerSavingModeList.add(BaseSelectEntity.createNormal("enable", false, "0001"))
        mPowerSavingModeList.add(BaseSelectEntity.createNormal("dormancy", false, "0002"))
    }

    //节能模式
    fun powerSavingModeList(): MutableList<BaseSelectEntity> {
        return mPowerSavingModeList
    }

}