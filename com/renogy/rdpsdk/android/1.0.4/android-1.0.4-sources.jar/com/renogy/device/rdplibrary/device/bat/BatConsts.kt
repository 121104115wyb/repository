package com.renogy.device.rdplibrary.device.bat

import com.renogy.device.rdplibrary.ProtocolsConsts
import com.renogy.device.rdplibrary.R
import com.renogy.device.rdplibrary.device.anotation.DeviceType
import com.renogy.device.rdplibrary.device.anotation.ParseType
import com.renogy.device.rdplibrary.device.entity.BaseSelectEntity

/**
 * @author Create by 17474 on 2024/11/11.
 * Email： lishuwentimor1994@163.com
 * Describe：电池 3206100206677
 */
object BatConsts {

    //device address
    var DEVICE_ADDRESS = getTag("device_address", ParseType.PARSE_NOT)

    //device model
    var SKU = getTag("sku", ParseType.PARSE_ASCII)

    //固件版本
    var FIRMWARE_VERSION = getTag("firmware_version", ParseType.PARSE_NOT)

    //电池电压
    var BATTERY_VOLTS = getTag("battery_volts", ParseType.TENTHS_COEFFICIENT)

    //电池电流
    var BATTERY_AMPS = getTag("battery_amps", ParseType.PERCENTILES_COEFFICIENT)

    //剩余容量
    var REMAIN_CAPACITY = getTag("remain_capacity", ParseType.THOUSANDTH_COEFFICIENT)

    //电池总容量
    var TOTAL_CAPACITY = getTag("total_capacity", ParseType.THOUSANDTH_COEFFICIENT)

    //电池电芯数量
    var BATTERY_CELLS_NUMBER = getTag("battery_cells_number", ParseType.COEFFICIENT)

    //电池温度电芯数量
    var BATTERY_TEMPERATURE_CELLS_NUMBER =
        getTag("battery_temperature_cells_number", ParseType.COEFFICIENT)

    //电池电芯电压
    var BATTERY_CELLS_VOLTS = getTag("battery_cells_volts", ParseType.BAT_CELL_VOLTS)

    //电池电芯温度
    var BATTERY_CELLS_TEMPERATURE = getTag("battery_cells_temperature", ParseType.BAT_CELL_TEMP)

    //加热膜状态
    var HEATER_MODE_STATUS = getTag("heater_mode_status", ParseType.BIT)


    private fun getTag(description: String, @ParseType parseType: String): String {
        return DeviceType.BAT + ProtocolsConsts.SEPARATOR + description + ProtocolsConsts.SEPARATOR + parseType
    }

    //电池加热膜状态
    private val mBatHeatModeList = mutableListOf<BaseSelectEntity>()

    init {
        mBatHeatModeList.add(BaseSelectEntity.createTvRes(R.string.text_switch_on, false, "1"))
        mBatHeatModeList.add(BaseSelectEntity.createTvRes(R.string.text_switch_off, false, "0"))
    }

    public fun getBatHeatModeList(): MutableList<BaseSelectEntity> {
        return mBatHeatModeList
    }

}