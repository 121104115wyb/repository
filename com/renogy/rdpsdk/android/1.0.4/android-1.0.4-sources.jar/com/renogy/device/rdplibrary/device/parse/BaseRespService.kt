package com.renogy.device.rdplibrary.device.parse

import com.renogy.device.rdplibrary.device.entity.BaseParseEntity

/**
 * @author Create by 17474 on 2024/11/12.
 * Email： lishuwentimor1994@163.com
 * Describe：数据解析
 */
interface BaseRespService {

    fun parse(cmdTag: String, hexResp: String, parseType: String): BaseParseEntity
}