package com.renogy.device.rdplibrary.device.entity

import com.renogy.device.rdplibrary.R

/**
 * @author Create by 17474 on 2024/11/13.
 * Email： lishuwentimor1994@163.com
 * Describe：资源类型解析，适配多语言
 * @param intRes 文字资源
 * @param hexResp 响应值
 */
class ResParseEntity(var intRes: Int? = R.string.text_device_default_title, hexResp: String) :
    BaseParseEntity(hexResp) {
}