package com.renogy.device.rdplibrary.device.parse.type

import com.renogy.device.rdplibrary.device.entity.BaseParseEntity
import com.renogy.device.rdplibrary.device.entity.BaseSelectEntity
import com.renogy.device.rdplibrary.device.entity.IntParseEntity
import com.renogy.device.rdplibrary.device.entity.StringParseEntity
import com.renogy.device.rdplibrary.utils.ModBusUtils

/**
 * @author Create by 17474 on 2024/11/12.
 * Email： lishuwentimor1994@163.com
 * Describe：bit位解析，默认只支持2个字节
 * @param selectList 选项
 * @param start 开始位
 * @param end 结束位
 */
class ParseBit(
    var selectList: MutableList<BaseSelectEntity>? = null,
    var start: Int = 0,
    var end: Int = 0
) : BaseParseService() {
    override fun parse(hexResp: String): BaseParseEntity {
        if (start > end || end > 16 || start < 0) return StringParseEntity("--", "")
        val fullBits = ModBusUtils.hexToFullByte(hexResp)
        val bit13Str = fullBits.substring(16 - end, 16 - start).toInt()
        return StringParseEntity(
            selectList?.find { it.hexTag == ModBusUtils.num2Hex1(bit13Str) }?.showTitle(),
            hexResp
        )
    }
}